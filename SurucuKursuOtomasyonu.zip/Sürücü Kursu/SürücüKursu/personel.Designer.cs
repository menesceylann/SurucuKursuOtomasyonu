﻿namespace SürücüKursu
{
    partial class personel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(personel));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.p_görev = new System.Windows.Forms.TextBox();
            this.p_eposta = new System.Windows.Forms.TextBox();
            this.p_telefon = new System.Windows.Forms.TextBox();
            this.p_soyadi = new System.Windows.Forms.TextBox();
            this.p_ad = new System.Windows.Forms.TextBox();
            this.p_tc_kimlik = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.buttonGüncelle = new System.Windows.Forms.Button();
            this.buttonCikis = new System.Windows.Forms.Button();
            this.buttonSil = new System.Windows.Forms.Button();
            this.hata = new System.Windows.Forms.ErrorProvider(this.components);
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.Location = new System.Drawing.Point(4, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(603, 135);
            this.dataGridView1.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.p_görev);
            this.groupBox9.Controls.Add(this.p_eposta);
            this.groupBox9.Controls.Add(this.p_telefon);
            this.groupBox9.Controls.Add(this.p_soyadi);
            this.groupBox9.Controls.Add(this.p_ad);
            this.groupBox9.Controls.Add(this.p_tc_kimlik);
            this.groupBox9.Controls.Add(this.label105);
            this.groupBox9.Controls.Add(this.label102);
            this.groupBox9.Controls.Add(this.label101);
            this.groupBox9.Controls.Add(this.label100);
            this.groupBox9.Controls.Add(this.label99);
            this.groupBox9.Controls.Add(this.label98);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox9.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox9.Location = new System.Drawing.Point(4, 158);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(603, 378);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            // 
            // p_görev
            // 
            this.p_görev.Location = new System.Drawing.Point(193, 327);
            this.p_görev.Margin = new System.Windows.Forms.Padding(4);
            this.p_görev.Name = "p_görev";
            this.p_görev.Size = new System.Drawing.Size(199, 23);
            this.p_görev.TabIndex = 23;
            // 
            // p_eposta
            // 
            this.p_eposta.Location = new System.Drawing.Point(193, 269);
            this.p_eposta.Margin = new System.Windows.Forms.Padding(4);
            this.p_eposta.Name = "p_eposta";
            this.p_eposta.Size = new System.Drawing.Size(199, 23);
            this.p_eposta.TabIndex = 21;
            // 
            // p_telefon
            // 
            this.p_telefon.Location = new System.Drawing.Point(193, 212);
            this.p_telefon.Margin = new System.Windows.Forms.Padding(4);
            this.p_telefon.MaxLength = 11;
            this.p_telefon.Name = "p_telefon";
            this.p_telefon.Size = new System.Drawing.Size(199, 23);
            this.p_telefon.TabIndex = 19;
            // 
            // p_soyadi
            // 
            this.p_soyadi.Location = new System.Drawing.Point(193, 155);
            this.p_soyadi.Margin = new System.Windows.Forms.Padding(4);
            this.p_soyadi.MaxLength = 25;
            this.p_soyadi.Name = "p_soyadi";
            this.p_soyadi.Size = new System.Drawing.Size(199, 23);
            this.p_soyadi.TabIndex = 18;
            // 
            // p_ad
            // 
            this.p_ad.Location = new System.Drawing.Point(193, 98);
            this.p_ad.Margin = new System.Windows.Forms.Padding(4);
            this.p_ad.MaxLength = 25;
            this.p_ad.Name = "p_ad";
            this.p_ad.Size = new System.Drawing.Size(199, 23);
            this.p_ad.TabIndex = 17;
            // 
            // p_tc_kimlik
            // 
            this.p_tc_kimlik.Location = new System.Drawing.Point(193, 41);
            this.p_tc_kimlik.Margin = new System.Windows.Forms.Padding(4);
            this.p_tc_kimlik.MaxLength = 11;
            this.p_tc_kimlik.Name = "p_tc_kimlik";
            this.p_tc_kimlik.Size = new System.Drawing.Size(199, 23);
            this.p_tc_kimlik.TabIndex = 8;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.ForeColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(190, 306);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(61, 17);
            this.label105.TabIndex = 7;
            this.label105.Text = "Görevi ";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.ForeColor = System.Drawing.Color.Black;
            this.label102.Location = new System.Drawing.Point(190, 248);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(65, 17);
            this.label102.TabIndex = 4;
            this.label102.Text = "E-Posta";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.ForeColor = System.Drawing.Color.Black;
            this.label101.Location = new System.Drawing.Point(192, 191);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(63, 17);
            this.label101.TabIndex = 3;
            this.label101.Text = "Telefon";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.ForeColor = System.Drawing.Color.Black;
            this.label100.Location = new System.Drawing.Point(192, 134);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(57, 17);
            this.label100.TabIndex = 2;
            this.label100.Text = "Soyadı";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.ForeColor = System.Drawing.Color.Black;
            this.label99.Location = new System.Drawing.Point(192, 77);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(31, 17);
            this.label99.TabIndex = 1;
            this.label99.Text = "Adı";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.ForeColor = System.Drawing.Color.Black;
            this.label98.Location = new System.Drawing.Point(190, 20);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(153, 17);
            this.label98.TabIndex = 0;
            this.label98.Text = "T.C Kimlik Numarası";
            // 
            // buttonGüncelle
            // 
            this.buttonGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonGüncelle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonGüncelle.ImageKey = "yenile.png";
            this.buttonGüncelle.ImageList = this.ımageList1;
            this.buttonGüncelle.Location = new System.Drawing.Point(4, 543);
            this.buttonGüncelle.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGüncelle.Name = "buttonGüncelle";
            this.buttonGüncelle.Size = new System.Drawing.Size(149, 49);
            this.buttonGüncelle.TabIndex = 24;
            this.buttonGüncelle.Text = "GÜNCELLE";
            this.buttonGüncelle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonGüncelle.UseVisualStyleBackColor = true;
            this.buttonGüncelle.Click += new System.EventHandler(this.buttonGüncelle_Click);
            // 
            // buttonCikis
            // 
            this.buttonCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonCikis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCikis.ImageKey = "cikis.png";
            this.buttonCikis.ImageList = this.ımageList3;
            this.buttonCikis.Location = new System.Drawing.Point(504, 544);
            this.buttonCikis.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCikis.Name = "buttonCikis";
            this.buttonCikis.Size = new System.Drawing.Size(103, 49);
            this.buttonCikis.TabIndex = 26;
            this.buttonCikis.Text = "ÇIKIŞ";
            this.buttonCikis.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonCikis.UseVisualStyleBackColor = true;
            this.buttonCikis.Click += new System.EventHandler(this.buttonCikis_Click_1);
            // 
            // buttonSil
            // 
            this.buttonSil.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonSil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSil.ImageKey = "cop.png";
            this.buttonSil.ImageList = this.ımageList2;
            this.buttonSil.Location = new System.Drawing.Point(159, 543);
            this.buttonSil.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSil.Name = "buttonSil";
            this.buttonSil.Size = new System.Drawing.Size(93, 49);
            this.buttonSil.TabIndex = 25;
            this.buttonSil.Text = "SİL";
            this.buttonSil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSil.UseVisualStyleBackColor = false;
            this.buttonSil.Click += new System.EventHandler(this.buttonSil_Click);
            // 
            // hata
            // 
            this.hata.ContainerControl = this;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "yenile.png");
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "cikis.png");
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "cop.png");
            // 
            // personel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(614, 594);
            this.Controls.Add(this.buttonCikis);
            this.Controls.Add(this.buttonGüncelle);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.buttonSil);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "personel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personel Bilgileri";
            this.Load += new System.EventHandler(this.PersonelBilgileri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox p_görev;
        private System.Windows.Forms.TextBox p_eposta;
        private System.Windows.Forms.TextBox p_telefon;
        private System.Windows.Forms.TextBox p_soyadi;
        private System.Windows.Forms.TextBox p_ad;
        private System.Windows.Forms.TextBox p_tc_kimlik;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Button buttonGüncelle;
        private System.Windows.Forms.Button buttonCikis;
        private System.Windows.Forms.Button buttonSil;
        private System.Windows.Forms.ErrorProvider hata;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.ImageList ımageList2;
    }
}