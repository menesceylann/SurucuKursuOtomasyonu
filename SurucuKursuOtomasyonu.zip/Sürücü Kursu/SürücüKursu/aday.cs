﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SürücüKursu
{
    public partial class aday : Form
    {

        OleDbConnection baglanti = new OleDbConnection(@"Provider=Microsoft.Ace.OLEDB.12.0;Data Source=" + Directory.GetCurrentDirectory() + @"\database.accdb");
        OleDbCommand komut = null;
        OleDbDataAdapter adapter = null;
        DataTable doldur = null;
        String rapor = "Seçim Yapılmadı";
        String belge = "Seçim Yapılmadı";


        public aday()
        {
            InitializeComponent();
        }

        private void griddoldur()
        {
            komut = new OleDbCommand("Select * From aday_bilgi Where tc_kimlik=?", baglanti);
            komut.Parameters.AddWithValue("?", AnaForm.id.ToString());
            adapter = new OleDbDataAdapter();
            doldur = new DataTable();
            adapter.SelectCommand = komut;
            adapter.Fill(doldur);
            dataGridView1.DataSource = doldur;
            komut.Dispose();
            adapter.Dispose();
        }

        private void aday_guncelle()
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || comboBox3.SelectedIndex == -1 || comboBox4.SelectedIndex == -1)
            {
                hata.SetError(textBox1, "Boş Geçilemez !!!");
                hata.SetError(textBox2, "Boş Geçilemez !!!");
                hata.SetError(textBox3, "Boş Geçilemez !!!");
                hata.SetError(textBox4, "Boş Geçilemez !!!");
                hata.SetError(textBox5, "Boş Geçilemez !!!");
                hata.SetError(comboBox3, "Boş Geçilemez !!!");
                hata.SetError(comboBox4, "Boş Geçilemez !!!");
            }
            else
            {
                DialogResult sonuc;
                sonuc = MessageBox.Show("Aday bilgileri güncellemeyi onaylıyor musunuz ?", "Bilgi Güncelleme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                if (sonuc == DialogResult.Yes)
                {

                    try
                    {
                        komut = new OleDbCommand("Update aday_bilgi set tc_kimlik=?,ad=?,soyad=?,yas=?,telefon=?,saglik_rapor=?,adli_belge=?,kayit_tarih=?,sinif_adi=?,ehliyet_sinifi=? Where tc_kimlik=?  ", baglanti);
                        komut.Parameters.AddWithValue("?", textBox1.Text);
                        komut.Parameters.AddWithValue("?", textBox2.Text);
                        komut.Parameters.AddWithValue("?", textBox3.Text);
                        komut.Parameters.AddWithValue("?", textBox4.Text);
                        komut.Parameters.AddWithValue("?", textBox5.Text);
                        komut.Parameters.AddWithValue("?", rapor);
                        komut.Parameters.AddWithValue("?", belge);
                        komut.Parameters.AddWithValue("?", dateTimePicker1.Value.ToString());
                        komut.Parameters.AddWithValue("?", comboBox3.SelectedItem.ToString());
                        komut.Parameters.AddWithValue("?", comboBox4.SelectedItem.ToString());
                        komut.Parameters.AddWithValue("?", AnaForm.id);

                        komut.ExecuteNonQuery();
                        MessageBox.Show("Aday bilgileriniz güncellendi !!!", "Güncelleme Başarılı !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        komut.Dispose();
                        adapter.Dispose();
                        griddoldur();
                        AnaForm listele = (AnaForm)Application.OpenForms["anaform"];
                        listele.grid_doldur();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Aday bilgilerini güncellerken sistemde hata oluştu !!! Hata Bilgisi " + ex, "Aday bilgileri güncelleme Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    }
                }

            }
        }

        private void aday_sil()
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("Aday bilgileri silmeyi onaylıyor musunuz ?", "Bilgi Güncelleme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

            if (sonuc == DialogResult.Yes)
            {

                try
                {
                    komut = new OleDbCommand("Delete From aday_bilgi where aday_id=?", baglanti);
                    komut.Parameters.AddWithValue("?", AnaForm.id);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Seçilen aday bilgisi silindi !!!", "Silme işlemi Başarılı !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    AnaForm listele = (AnaForm)Application.OpenForms["anaform"];
                    listele.grid_doldur();
                    this.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Aday bilgilerini silerken sistemde hata oluştu !!! Hata Bilgisi " + ex, "Aday Silme İşlemi Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

                }  
            }
        }

        private void comboBox1_doldur()
        {
            comboBox3.SelectedText = "Birini Seçiniz";
            comboBox4.SelectedText = "Birini Seçiniz";
        
        

            comboBox3.Items.Add("2022/1 Gündüz");
            comboBox3.Items.Add("2022/1 Gece");
            comboBox3.Items.Add("2022/2 Gündüz");
            comboBox3.Items.Add("2022/2 Gece");

            comboBox4.Items.Add("A");
            comboBox4.Items.Add("A1");
            comboBox4.Items.Add("A2");
            comboBox4.Items.Add("B");
            comboBox4.Items.Add("B1");
            comboBox4.Items.Add("BE");
            comboBox4.Items.Add("C");
            comboBox4.Items.Add("C1");
            comboBox4.Items.Add("CE");
            comboBox4.Items.Add("C1E");
            comboBox4.Items.Add("D");
            comboBox4.Items.Add("D1");
            comboBox4.Items.Add("DE");
            comboBox4.Items.Add("D1E");
            comboBox4.Items.Add("F");
            comboBox4.Items.Add("M");
        }

        private void AdayBilgileri_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            griddoldur();
            baglanti.Close();
            comboBox1_doldur();
            
        }

        private void buttonCikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonGüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            aday_guncelle();
            baglanti.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                rapor = "Var";
            }
            else
            {
                rapor = "Seçim Yapılmadı";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                rapor = "Yok";
            }
            else
            {
                rapor = "Seçim Yapılmadı";
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                belge = "Var";
            }
            else
            {
                belge = "Seçim Yapılmadı";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                belge = "Yok";
            }
            else
            {
                belge = "Seçim Yapılmadı";
            }
        }

        private void buttonSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            aday_sil();
            baglanti.Close();
        }
    }
}
