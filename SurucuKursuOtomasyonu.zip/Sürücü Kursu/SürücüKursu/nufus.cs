﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace SürücüKursu
{
    public partial class nufus : Form
    {
        public nufus()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection(@"Provider=Microsoft.Ace.OLEDB.12.0;Data Source=" + Directory.GetCurrentDirectory() + @"\database.accdb");
        OleDbCommand komut = null;
        OleDbDataAdapter adapter = null;
        DataTable doldur = null;

        private void griddoldur()
        {
            komut = new OleDbCommand("Select * From nufus Where tc=?", baglanti);
            komut.Parameters.AddWithValue("?", AnaForm.id.ToString());
            adapter = new OleDbDataAdapter();
            doldur = new DataTable();
            adapter.SelectCommand = komut;
            adapter.Fill(doldur);
            dataGridView1.DataSource = doldur;
            komut.Dispose();
            adapter.Dispose();
        }

        private void guncelle()
        {
            if (tc_kimlik.Text == "" || ad.Text == "" || soyad.Text == "" || baba.Text == "" || ana.Text == "" || dogum_yeri.Text == "" || kan_grup.Text == "" || il.Text == "" || ilçe.Text == "" )
            {
                hata.SetError(tc_kimlik, "Boş Geçilemez !!!");
                hata.SetError(ad, "Boş Geçilemez !!!");
                hata.SetError(soyad, "Boş Geçilemez !!!");
                hata.SetError(baba, "Boş Geçilemez !!!");
                hata.SetError(ana, "Boş Geçilemez !!!");
                hata.SetError(dogum_yeri, "Boş Geçilemez !!!");
                hata.SetError(kan_grup, "Boş Geçilemez !!!");
                hata.SetError(il, "Boş Geçilemez !!!");
                hata.SetError(ilçe, "Boş Geçilemez !!!");
            }
            else
            {

                try
                {

                    DialogResult sonuc;
                    sonuc = MessageBox.Show("Kursiyer bilgilerini onaylıyor musunuz ?", "Sisteme Kayıt Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                    if (sonuc == DialogResult.Yes)
                    {
                        komut = new OleDbCommand("update nufus set numara=@no,tc=@tc,adi=@adi,soyadi=@soyadi,baba=@baba,ana=@ana,dogum=@dogum,dogum_tarih=@dogum_tarih,kan_grup=@kan_grup,il=@il,ilce=@ilce Where tc='" + AnaForm.id + "'", baglanti);
                        komut.Parameters.AddWithValue("@tc", tc_kimlik.Text);
                        komut.Parameters.AddWithValue("@adi", ad.Text);
                        komut.Parameters.AddWithValue("@soyadi", soyad.Text);
                        komut.Parameters.AddWithValue("@baba", baba.Text);
                        komut.Parameters.AddWithValue("@ana", ana.Text);
                        komut.Parameters.AddWithValue("@dogum", dogum_yeri.Text);
                        komut.Parameters.AddWithValue("@dogum_tarih", dogum_tarih.Value.ToString());
                        komut.Parameters.AddWithValue("@kan_grup", kan_grup.Text);
                        komut.Parameters.AddWithValue("@il", il.Text);
                        komut.Parameters.AddWithValue("@ilce", ilçe.Text);
                        komut.ExecuteNonQuery();
                        komut.Dispose();
                        griddoldur();
                        MessageBox.Show("Kursiyer Nufus bilgileri başarı ile güncellenmiştir !!! ", "Güncelleme Başarılı !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kursiyer Nufus bilgileri güncellenlenirken hata oluştu !!! Hata Bilgisi " + ex, "Kişisel Bilgiler Güncelleme Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }
        }

        private void NufusBilgileri_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            griddoldur();
            baglanti.Close();
        }

        private void buttonSil_Click(object sender, EventArgs e)
        {

        }

        private void buttonCikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonGüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            guncelle();
            baglanti.Close();
        }

        private void aday_nufus_sil()
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("Aday bilgilerini silmeyi onaylıyor musunuz ?", "Bilgi Güncelleme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

            if (sonuc == DialogResult.Yes)
            {

                try
                {
                    komut = new OleDbCommand("Delete From nufus where tc=?", baglanti);
                    komut.Parameters.AddWithValue("?", AnaForm.id);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Seçilen aday nufus bilgisi silindi !!!", "Silme işlemi Başarılı !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Aday bilgilerini silerken sistemde hata oluştu !!! Hata Bilgisi " + ex, "Aday Silme İşlemi Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

                }
            }
        }

        private void buttonSil_Click_1(object sender, EventArgs e)
        {
            baglanti.Open();
            aday_nufus_sil();
            baglanti.Close();
        }
    }
}
