﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SürücüKursu
{
    public partial class AnaForm : Form
    {
        public AnaForm()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection(@"Provider=Microsoft.Ace.OLEDB.12.0;Data Source=" + Directory.GetCurrentDirectory() + @"\database.accdb");
        OleDbCommand komut = null;
        OleDbDataAdapter adap = null;
        DataTable doldur = null;
        OleDbDataReader oku = null;
        String rapor = "Seçim Yapılmadı";
        String belge = "Seçim Yapılmadı";
        public static String id = null;

        private void buttonCikis_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        private void buttonNüfüsBilgileri_Click(object sender, EventArgs e)
        {
         id = dataGridView1.CurrentRow.Cells["tc_kimlik"].Value.ToString();
         nufus nufus_bilgileri = new nufus();
         nufus_bilgileri.ShowDialog();
        }

        private void buttonAdayBilgileri_Click(object sender, EventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells["tc_kimlik"].Value.ToString();
            aday aday_bilgi = new aday();
            aday_bilgi.ShowDialog();
        }

   
        private void buttonCikis_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonOdemeler_Click_1(object sender, EventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells["tc_kimlik"].Value.ToString();
            odeme odemeler = new odeme();
            odemeler.ShowDialog();
        }

        private void buttonPersonelBilgileri_Click_1(object sender, EventArgs e)
        {
            id =  GridView2_personel.CurrentRow.Cells["per_tc"].Value.ToString();
            personel personel = new personel();
            personel.ShowDialog();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_doldur()
        {
            comboBox3.SelectedText = "Birini Seçiniz";
            comboBox4.SelectedText = "Birini Seçiniz";

         



            comboBox3.Items.Add("2022/1 Gündüz");
            comboBox3.Items.Add("2022/1 Gece");
            comboBox3.Items.Add("2022/2 Gündüz");
            comboBox3.Items.Add("2022/2 Gece");

            comboBox4.Items.Add("A1");
            comboBox4.Items.Add("A2");
            comboBox4.Items.Add("B");
            comboBox4.Items.Add("C");
            comboBox4.Items.Add("D");
            comboBox4.Items.Add("E");
            comboBox4.Items.Add("F");
            comboBox4.Items.Add("G");
            comboBox4.Items.Add("H");
            comboBox4.Items.Add("K");

        }
        public void grid_doldur()
        {
            try
            {
                adap = new OleDbDataAdapter("Select aday_id,tc_kimlik,ad,soyad,telefon,saglik_rapor,adli_belge,kayit_tarih,ehliyet_sinifi from aday_bilgi order by aday_id desc  ", baglanti);
                doldur = new DataTable();
                adap.Fill(doldur);
                dataGridView1.DataSource = doldur;
                adap.Dispose();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Aday bilgileri listelenirken hata oluştu !!! Hata Bilgisi " + ex, "Aday bilgileri gösterilemiyor !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            } 
        }
        private void personel_doldur()
        {
            try
            {
                adap = new OleDbDataAdapter("Select per_tc,per_adi,per_soyad,per_telefon,per_email,per_görevi From personel order by per_id desc", baglanti);
                doldur = new DataTable();
                adap.Fill(doldur);
                GridView2_personel.DataSource = doldur;
                adap.Dispose();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Personel bilgileri listelenirken hata oluştu !!! Hata Bilgisi " + ex, "Personel bilgileri gösterilemiyor !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            
            
        }
        private void AnaForm_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            comboBox1_doldur();
            grid_doldur();
            buttonPersonelBilgileri.Enabled = false;
            baglanti.Close();
        }

        private void kaydet()
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" ||  comboBox3.SelectedIndex == -1 || comboBox4.SelectedIndex == -1)
            {
                hata.SetError(textBox1, "Boş Geçilemez !!!");
                hata.SetError(textBox2, "Boş Geçilemez !!!");
                hata.SetError(textBox3, "Boş Geçilemez !!!");
                hata.SetError(textBox4, "Boş Geçilemez !!!");
                hata.SetError(textBox5, "Boş Geçilemez !!!");
                hata.SetError(comboBox3, "Boş Geçilemez !!!");
                hata.SetError(comboBox4, "Boş Geçilemez !!!");
            }
            else
            {
                try
                {

                    DialogResult sonuc;
                    sonuc = MessageBox.Show("Aday bilgilerini onaylıyor musunuz ?", "Sisteme Kayıt Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                    if (sonuc == DialogResult.Yes)
                    {
                        komut = new OleDbCommand("insert into aday_bilgi (tc_kimlik,ad,soyad,yas,telefon,saglik_rapor,adli_belge,kayit_tarih,sinif_adi,ehliyet_sinifi) Values (?,?,?,?,?,?,?,?,?,?)", baglanti);
                        komut.Parameters.AddWithValue("?", textBox1.Text);
                        komut.Parameters.AddWithValue("?", textBox2.Text);
                        komut.Parameters.AddWithValue("?", textBox3.Text);
                        komut.Parameters.AddWithValue("?", textBox4.Text);
                        komut.Parameters.AddWithValue("?", textBox5.Text);
                        komut.Parameters.AddWithValue("?", rapor);
                        komut.Parameters.AddWithValue("?", belge);
                        komut.Parameters.AddWithValue("?", dateTimePicker1.Value.ToString());
                        komut.Parameters.AddWithValue("?", comboBox3.SelectedItem.ToString());
                        komut.Parameters.AddWithValue("?", comboBox4.SelectedItem.ToString());
                        komut.ExecuteNonQuery();
                        komut.Dispose();
                        grid_doldur();
                        MessageBox.Show("Kursiyer bilgileri sisteme başarı ile girilmiştir !!! ", "Sürücü Kursu Yeni Kayıt !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        groupBox1.Enabled = false;
                        b_kaydet.Enabled = false;
                        yeni_kayit.Enabled = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kursiyer bilgileri sisteme kaydedilirken hata oluştu !!! Hata Bilgisi " + ex, "Yeni Kayıt Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }

        }

        private void b_kaydet_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            kaydet();
            baglanti.Close();
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                rapor = "Var";
            }
            else
            {
                rapor = "Seçim Yapılmadı";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                rapor = "Yok";
            }
            else
            {
                rapor = "Seçim Yapılmadı";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                belge = "Yok";
            }
            else
            {
                belge = "Seçim Yapılmadı";
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                belge = "Var";
            }
            else
            {
                belge = "Seçim Yapılmadı";
            }
        }

        private void yeni_kayit_Click(object sender, EventArgs e)
        {
            
            comboBox3.Text = null;
            comboBox4.Text = null;
            comboBox3.SelectedText = "Birini Seçiniz";
            comboBox4.SelectedText = "Birini Seçiniz";
            groupBox1.Enabled = true;
            b_kaydet.Enabled = true;
            yeni_kayit.Enabled = false;
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            textBox4.Text = null;
            textBox5.Text = null;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;

        }

        private void nufus_insert()
        {
            if ( tc_kimlik.Text == "" || ad.Text == "" || soyad.Text == "" || baba.Text == "" || ana.Text == "" || dogum_yeri.Text == "" || kan_grup.Text == "" || il.Text == "" || ilçe.Text == "" )
            {
                hata.SetError(tc_kimlik, "Boş Geçilemez !!!");
                hata.SetError(ad, "Boş Geçilemez !!!");
                hata.SetError(soyad, "Boş Geçilemez !!!");
                hata.SetError(baba, "Boş Geçilemez !!!");
                hata.SetError(ana, "Boş Geçilemez !!!");
                hata.SetError(dogum_yeri, "Boş Geçilemez !!!");
                hata.SetError(kan_grup, "Boş Geçilemez !!!");
                hata.SetError(il, "Boş Geçilemez !!!");
                hata.SetError(ilçe, "Boş Geçilemez !!!");
            }
            else
            {
                try
                {
                    DialogResult sonuc;
                    sonuc = MessageBox.Show("Kursiyer bilgilerini onaylıyor musunuz ?", "Sisteme Kayıt Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                    if (sonuc == DialogResult.Yes)
                    {
                        komut = new OleDbCommand("insert into nufus (seri_no,numara,tc,adi,soyadi,baba,ana,dogum,dogum_tarih,medeni,dini,kan_grup,il,ilce,mahalle,cilt_no,aile_sıra,sıra_no,v_yer,v_nedeni,kayit_no,verilis_tarih) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", baglanti);
                        komut.Parameters.AddWithValue("?", tc_kimlik.Text);
                        komut.Parameters.AddWithValue("?", ad.Text);
                        komut.Parameters.AddWithValue("?", soyad.Text);
                        komut.Parameters.AddWithValue("?", baba.Text);
                        komut.Parameters.AddWithValue("?", ana.Text);
                        komut.Parameters.AddWithValue("?", dogum_yeri.Text);
                        komut.Parameters.AddWithValue("?", dogum_tarih.Value.ToString());
                        komut.Parameters.AddWithValue("?", kan_grup.Text);
                        komut.Parameters.AddWithValue("?", il.Text);
                        komut.Parameters.AddWithValue("?", ilçe.Text);
                        komut.ExecuteNonQuery();
                        MessageBox.Show("Kursiyer Nufus bilgileri sisteme başarı ile girilmiştir !!! ", "Sürücü Kursu Yeni Kayıt !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        komut.Dispose();
                        
                        nufus_kaydet.Enabled = false;
                        tc_kimlik.Enabled = false;
                        ad.Enabled = false;
                        soyad.Enabled = false;
                        baba.Enabled = false;
                        ana.Enabled = false;
                        dogum_yeri.Enabled = false;
                        dogum_tarih.Enabled = false;
                        kan_grup.Enabled = false;
                        kan_grup.Enabled = false;
                        il.Enabled = false;
                        ilçe.Enabled = false;
                        nufus_yeni.Enabled = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kursiyer bilgileri sisteme kaydedilirken hata oluştu !!! Hata Bilgisi " + ex, "Kişisel Bilgiler Kayıt Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }

        }



        private void nufus_kaydet_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            nufus_insert();
            baglanti.Close();
        }


        private void odeme_kaydet()
        {
            
            if (o_tc_kimlik.Text == "" || o_tutar.Text == "" || t_borc.Text == "")
            {
                hata.SetError(o_tc_kimlik, "Boş Geçilemez !!!");
                hata.SetError(o_tutar, "Boş Geçilemez !!!");
                hata.SetError(t_borc, "Boş Geçilemez !!!");
            }
            else
            {
                try
                {
                    DialogResult sonuc;
                    sonuc = MessageBox.Show("Kursiyer Ödeme bilgilerini onaylıyor musunuz ?", "Ödeme bilgisi Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                    if (sonuc == DialogResult.Yes)
                    {

                        int toplam_borc = Convert.ToInt32(t_borc.Text);
                        int ödeme_tutar = Convert.ToInt32(o_tutar.Text);
                        int kalan_borc = toplam_borc - ödeme_tutar;

                        komut = new OleDbCommand("insert into odeme(tc_kimlik,o_tarih,toplam_borc,o_tutar,kalan_borc) Values (?,?,?,?,?)", baglanti);
                        komut.Parameters.AddWithValue("?", o_tc_kimlik.Text);
                        komut.Parameters.AddWithValue("?", odeme_dateTime.Value.ToString());
                        komut.Parameters.AddWithValue("?", t_borc.Text);
                        komut.Parameters.AddWithValue("?", o_tutar.Text);
                        komut.Parameters.AddWithValue("?", kalan_borc.ToString());
                        komut.ExecuteNonQuery();
                        komut.Dispose();

                        MessageBox.Show("Kursiyer Ödeme bilgileri sisteme başarı ile kaydedilmiştir !!! ", "Sürücü Kursu Ödeme Kayıt !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        o_tc_kimlik.Enabled = false;
                        odeme_dateTime.Enabled = false;
                        t_borc.Enabled = false;
                        o_tutar.Enabled = false;
                        ödeme_kaydet.Enabled = false;
                        ödeme_yeni.Enabled = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kursiyer Ödeme bilgileri sisteme kaydedilirken hata oluştu !!! Hata Bilgisi " + ex, "Yeni Kayıt Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }

        }


        private void ödeme_kaydet_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            odeme_kaydet();
            baglanti.Close();
            
        }

        private void ödeme_yeni_Click(object sender, EventArgs e)
        {
            o_tc_kimlik.Text = null;
            o_tutar.Text = null;
            t_borc.Text = null;
            o_tc_kimlik.Enabled = true;
            odeme_dateTime.Enabled = true;
            t_borc.Enabled = true;
            o_tutar.Enabled = true;
            ödeme_kaydet.Enabled = true;
            ödeme_yeni.Enabled = false;
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (kursiyer_panel.SelectedIndex == 4)
            {
                buttonPersonelBilgileri.Enabled = true;
                buttonAdayBilgileri.Enabled = false;
                buttonNüfüsBilgileri.Enabled = false;
                buttonOdemeler.Enabled = false;
                button_not.Enabled = false;
                liste_yenile.Enabled = false;
                personel_doldur();
            }
            else if (kursiyer_panel.SelectedIndex == 6)
            {
                buttonPersonelBilgileri.Enabled = false;
                buttonAdayBilgileri.Enabled = false;
                buttonNüfüsBilgileri.Enabled = false;
                buttonOdemeler.Enabled = false;
                button_not.Enabled = false;
                liste_yenile.Enabled = false;
                
            }
            else
            {
                buttonPersonelBilgileri.Enabled = false;
                buttonAdayBilgileri.Enabled = true;
                buttonNüfüsBilgileri.Enabled = true;
                buttonOdemeler.Enabled = true;
                button_not.Enabled = true;
                liste_yenile.Enabled = true;
            }
        }

        private void notbilgi_kaydet()
        {
            if (not_tc.Text == "" || not_ilkyardim.Text == "" || not_motor.Text == "" || not_trafik.Text == "")
            {
                hata.SetError(not_tc, "Boş Geçilemez !!!");
                hata.SetError(not_ilkyardim, "Boş Geçilemez !!!");
                hata.SetError(not_motor, "Boş Geçilemez !!!");
                hata.SetError(not_trafik, "Boş Geçilemez !!!");
            }
            else
            {
                DialogResult sonuc;
                sonuc = MessageBox.Show("Kursiyer Not bilgilerini onaylıyor musunuz ?", "Ödeme bilgisi Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                if (sonuc == DialogResult.Yes)
                {
                    try
                    {
                        komut = new OleDbCommand("insert into notlar(tc_kimlik,s_tarih,trafik_notu,motor_notu,ilkyardim_notu) values(?,?,?,?,?)", baglanti);
                        komut.Parameters.AddWithValue("?", not_tc.Text);
                        komut.Parameters.AddWithValue("?", not_dateTimePicker2.Value.ToString());
                        komut.Parameters.AddWithValue("?", not_trafik.Text);
                        komut.Parameters.AddWithValue("?", not_motor.Text);
                        komut.Parameters.AddWithValue("?", not_ilkyardim.Text);
                        komut.ExecuteNonQuery();
                        komut.Dispose();
                        MessageBox.Show("Kursiyer Not bilgileri sisteme başarı ile kaydedilmiştir !!! ", "Sürücü Kursu Not Kayıt !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        not_tc.Enabled = false;
                        not_motor.Enabled = false;
                        not_trafik.Enabled = false;
                        not_ilkyardim.Enabled = false;
                        not_dateTimePicker2.Enabled = false;
                        not_bilgi_kaydet.Enabled = false;
                        not_yeni_k.Enabled = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Kursiyer Not bilgileri sisteme kaydedilirken hata oluştu !!! Hata Bilgisi " + ex, "Yeni Kayıt Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    }
                }
            }
        }

        private void not_bilgi_kaydet_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            notbilgi_kaydet();
            baglanti.Close();

        }

        private void not_yeni_k_Click(object sender, EventArgs e)
        {
            not_tc.Enabled = true;
            not_motor.Enabled = true;
            not_trafik.Enabled = true;
            not_ilkyardim.Enabled = true;
            not_dateTimePicker2.Enabled = true;
            not_bilgi_kaydet.Enabled = true;
            not_yeni_k.Enabled = false;
            not_tc.Text = null;
            not_motor.Text = null;
            not_trafik.Text = null;
            not_ilkyardim.Text = null;
        }

        private void personel_kaydet()
        {
            if (p_ad.Text == "" ||  p_eposta.Text == "" || p_görev.Text == "" || p_soyadi.Text == "" || p_tc_kimlik.Text == "" || p_telefon.Text == "")
            {
                hata.SetError(p_ad, "Boş Geçilemez !!!");
                hata.SetError(p_eposta, "Boş Geçilemez !!!");
                hata.SetError(p_görev, "Boş Geçilemez !!!");
                hata.SetError(p_soyadi, "Boş Geçilemez !!!");
                hata.SetError(p_tc_kimlik, "Boş Geçilemez !!!");
                hata.SetError(p_telefon, "Boş Geçilemez !!!");
            }
            else
            {
                DialogResult sonuc;
                sonuc = MessageBox.Show("Personel bilgilerini onaylıyor musunuz ?", "Ödeme bilgisi Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                if (sonuc == DialogResult.Yes)
                {
                    try
                    {
                        komut = new OleDbCommand("insert into personel(per_tc,per_adi,per_soyad,per_telefon,per_email,per_görevi) values(?,?,?,?,?,?)", baglanti);
                        komut.Parameters.AddWithValue("?", p_tc_kimlik.Text);
                        komut.Parameters.AddWithValue("?", p_ad.Text);
                        komut.Parameters.AddWithValue("?", p_soyadi.Text);
                        komut.Parameters.AddWithValue("?", p_telefon.Text);
                        komut.Parameters.AddWithValue("?", p_eposta.Text);
                        komut.Parameters.AddWithValue("?", p_görev.Text);
                        komut.ExecuteNonQuery();
                        personel_doldur();
                        komut.Dispose();
                        MessageBox.Show("Personel bilgileri sisteme başarı ile kaydedilmiştir !!! ", "Sürücü Kursu Personel Kayıt !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                        p_ad.Enabled = false;
                        p_eposta.Enabled = false;
                        p_görev.Enabled = false;
                        p_soyadi.Enabled = false;
                        p_tc_kimlik.Enabled = false;
                        p_telefon.Enabled = false;
                        p_bilgikaydet.Enabled = false;
                        p_yenikayit.Enabled = true;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Kursiyer Not bilgileri sisteme kaydedilirken hata oluştu !!! Hata Bilgisi " + ex, "Yeni Kayıt Hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    }
                }
            }


        }


        private void p_bilgikaydet_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            personel_kaydet();
            baglanti.Close();
        }

        private void p_yenikayit_Click(object sender, EventArgs e)
        {
            p_ad.Text = null;
            p_eposta.Text = null;
            p_görev.Text = null;
            p_soyadi.Text = null;
            p_tc_kimlik.Text = null;
            p_telefon.Text = null;
            p_ad.Enabled =true;
            p_eposta.Enabled = true;
            p_görev.Enabled = true;
            p_soyadi.Enabled = true;
            p_tc_kimlik.Enabled = true;
            p_telefon.Enabled = true;
            p_bilgikaydet.Enabled = true;
            p_yenikayit.Enabled = false;
        }
        
        private void liste_yenile_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            grid_doldur();
            baglanti.Close();
        }

        private void nufus_yeni_Click(object sender, EventArgs e)
        {
            nufus_kaydet.Enabled = true;
            tc_kimlik.Enabled = true;
            ad.Enabled = true;
            soyad.Enabled = true;
            baba.Enabled = true;
            ana.Enabled = true;
            dogum_yeri.Enabled = true;
            dogum_tarih.Enabled = true;
            kan_grup.Enabled = true;
            kan_grup.Enabled = true;
            il.Enabled = true;
            ilçe.Enabled = true;
            nufus_yeni.Enabled = false;
            nufus_kaydet.Enabled = true;
        }

        private void button_not_Click(object sender, EventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells["tc_kimlik"].Value.ToString();
            notlar notlar = new notlar();
            notlar.ShowDialog();
        }

        private void sifre_degis()
        {
            if (per_number.Text == "" || m_sifre.Text == "" || y_sifre.Text == "" || y_s_tekrar.Text == "")
            {
                hata.SetError(per_number, "Boş Geçilemez !!!");
                hata.SetError(m_sifre, "Boş Geçilemez !!!");
                hata.SetError(y_sifre, "Boş Geçilemez !!!");
                hata.SetError(y_s_tekrar, "Boş Geçilemez !!!");

            }
            else
            {
                if (y_sifre.Text != y_s_tekrar.Text)
                {
                    MessageBox.Show("Şifreleriniz birbiri ile uyumlu degildir !!!", "Yeni şifrelerinizi kontrol ediniz !!!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                {

                    DialogResult sonuc;
                    sonuc = MessageBox.Show("Kullanici şifrenizi değiştirmeyi onaylıyor musunuz ?", "Şifre Degiştirme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                    if (sonuc == DialogResult.Yes)
                    {
                        try
                        {
                            komut = new OleDbCommand("Select * from giris Where kul_sifre=@kul_sifre and per_numarası=@per_number", baglanti);
                            komut.Parameters.AddWithValue("@kul_sifre", m_sifre.Text);
                            komut.Parameters.AddWithValue("@per_number", per_number.Text);
                            oku = komut.ExecuteReader();
                            if (oku.Read() == true)
                            {
                                komut = new OleDbCommand("Update giris set kul_sifre=? Where per_numarası=?", baglanti);
                                komut.Parameters.AddWithValue("?", y_sifre.Text);
                                komut.Parameters.AddWithValue("?", per_number.Text);
                                komut.ExecuteNonQuery();
                                komut.Dispose();
                                MessageBox.Show("Şifreniz degiştirilmiştir !!!", "Şifre degişikliği bilgisi !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                                per_number.Text = null;
                                m_sifre.Text = null;
                                y_sifre.Text = null;
                                y_s_tekrar.Text = null;
                            }
                            else
                            {
                                MessageBox.Show("Personel Numaranızı veya Mevcut Şifrenizi hatalı girdiniz, Lütfen tekrar deneyiniz !!!", "Şifreniz Hatalı !!!", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                                m_sifre.Text = null;
                                y_sifre.Text = null;
                                y_s_tekrar.Text = null;
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Şifre degiştirme işlemi gerçekleşirken sistemde hata oluştu !!! Hata Bilgisi " + ex, "Personel şifre degiştirme hatası !!!", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

                        }
                    }
                }
            }
        }

        private void sifre_degistir_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            sifre_degis();
            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}


       
 

