﻿namespace SürücüKursu
{
    partial class sifirla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sifirla));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.kapat = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.y_tekrar = new System.Windows.Forms.TextBox();
            this.y_sifre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.s_yenile = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.p_eposta = new System.Windows.Forms.TextBox();
            this.p_number = new System.Windows.Forms.TextBox();
            this.p_tc = new System.Windows.Forms.TextBox();
            this.p_soyadi = new System.Windows.Forms.TextBox();
            this.p_adi = new System.Windows.Forms.TextBox();
            this.k_adi = new System.Windows.Forms.TextBox();
            this.e_posta = new System.Windows.Forms.Label();
            this.per_number = new System.Windows.Forms.Label();
            this.tc_kimlik = new System.Windows.Forms.Label();
            this.per_soy = new System.Windows.Forms.Label();
            this.per_adi = new System.Windows.Forms.Label();
            this.kul_adi = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkCyan;
            this.groupBox1.Controls.Add(this.kapat);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.s_yenile);
            this.groupBox1.Controls.Add(this.p_eposta);
            this.groupBox1.Controls.Add(this.p_number);
            this.groupBox1.Controls.Add(this.p_tc);
            this.groupBox1.Controls.Add(this.p_soyadi);
            this.groupBox1.Controls.Add(this.p_adi);
            this.groupBox1.Controls.Add(this.k_adi);
            this.groupBox1.Controls.Add(this.e_posta);
            this.groupBox1.Controls.Add(this.per_number);
            this.groupBox1.Controls.Add(this.tc_kimlik);
            this.groupBox1.Controls.Add(this.per_soy);
            this.groupBox1.Controls.Add(this.per_adi);
            this.groupBox1.Controls.Add(this.kul_adi);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(-6, -3);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(499, 684);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // kapat
            // 
            this.kapat.Enabled = false;
            this.kapat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.kapat.ImageKey = "cikis.png";
            this.kapat.ImageList = this.ımageList2;
            this.kapat.Location = new System.Drawing.Point(346, 583);
            this.kapat.Margin = new System.Windows.Forms.Padding(4);
            this.kapat.Name = "kapat";
            this.kapat.Size = new System.Drawing.Size(117, 56);
            this.kapat.TabIndex = 10;
            this.kapat.Text = "ÇIKIŞ";
            this.kapat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.kapat.UseVisualStyleBackColor = true;
            this.kapat.Click += new System.EventHandler(this.kapat_Click);
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "cikis.png");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.y_tekrar);
            this.groupBox2.Controls.Add(this.y_sifre);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(8, 408);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(477, 156);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // y_tekrar
            // 
            this.y_tekrar.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.y_tekrar.ForeColor = System.Drawing.Color.Black;
            this.y_tekrar.Location = new System.Drawing.Point(142, 109);
            this.y_tekrar.Margin = new System.Windows.Forms.Padding(4);
            this.y_tekrar.MaxLength = 8;
            this.y_tekrar.Name = "y_tekrar";
            this.y_tekrar.Size = new System.Drawing.Size(184, 23);
            this.y_tekrar.TabIndex = 8;
            this.y_tekrar.UseSystemPasswordChar = true;
            this.y_tekrar.TextChanged += new System.EventHandler(this.y_tekrar_TextChanged);
            // 
            // y_sifre
            // 
            this.y_sifre.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.y_sifre.ForeColor = System.Drawing.Color.Black;
            this.y_sifre.Location = new System.Drawing.Point(141, 61);
            this.y_sifre.Margin = new System.Windows.Forms.Padding(4);
            this.y_sifre.MaxLength = 8;
            this.y_sifre.Name = "y_sifre";
            this.y_sifre.Size = new System.Drawing.Size(184, 23);
            this.y_sifre.TabIndex = 7;
            this.y_sifre.UseSystemPasswordChar = true;
            this.y_sifre.TextChanged += new System.EventHandler(this.y_sifre_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(139, 88);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "Tekrar";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(139, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Yeni Şifreniz";
            // 
            // s_yenile
            // 
            this.s_yenile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.s_yenile.ImageKey = "yenile.png";
            this.s_yenile.ImageList = this.ımageList3;
            this.s_yenile.Location = new System.Drawing.Point(27, 583);
            this.s_yenile.Margin = new System.Windows.Forms.Padding(4);
            this.s_yenile.Name = "s_yenile";
            this.s_yenile.Size = new System.Drawing.Size(211, 56);
            this.s_yenile.TabIndex = 9;
            this.s_yenile.Text = "ŞİFREYİ DEĞİŞTİR";
            this.s_yenile.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.s_yenile.UseVisualStyleBackColor = true;
            this.s_yenile.Click += new System.EventHandler(this.s_yenile_Click);
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "yenile.png");
            // 
            // p_eposta
            // 
            this.p_eposta.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p_eposta.ForeColor = System.Drawing.Color.Black;
            this.p_eposta.Location = new System.Drawing.Point(153, 357);
            this.p_eposta.Margin = new System.Windows.Forms.Padding(4);
            this.p_eposta.MaxLength = 30;
            this.p_eposta.Name = "p_eposta";
            this.p_eposta.Size = new System.Drawing.Size(184, 23);
            this.p_eposta.TabIndex = 6;
            this.p_eposta.TextChanged += new System.EventHandler(this.p_eposta_TextChanged);
            // 
            // p_number
            // 
            this.p_number.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p_number.ForeColor = System.Drawing.Color.Black;
            this.p_number.Location = new System.Drawing.Point(153, 302);
            this.p_number.Margin = new System.Windows.Forms.Padding(4);
            this.p_number.MaxLength = 9;
            this.p_number.Name = "p_number";
            this.p_number.Size = new System.Drawing.Size(184, 23);
            this.p_number.TabIndex = 5;
            this.p_number.TextChanged += new System.EventHandler(this.p_number_TextChanged);
            // 
            // p_tc
            // 
            this.p_tc.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p_tc.ForeColor = System.Drawing.Color.Black;
            this.p_tc.Location = new System.Drawing.Point(153, 246);
            this.p_tc.Margin = new System.Windows.Forms.Padding(4);
            this.p_tc.MaxLength = 11;
            this.p_tc.Name = "p_tc";
            this.p_tc.Size = new System.Drawing.Size(184, 23);
            this.p_tc.TabIndex = 4;
            this.p_tc.TextChanged += new System.EventHandler(this.p_tc_TextChanged);
            // 
            // p_soyadi
            // 
            this.p_soyadi.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p_soyadi.ForeColor = System.Drawing.Color.Black;
            this.p_soyadi.Location = new System.Drawing.Point(153, 188);
            this.p_soyadi.Margin = new System.Windows.Forms.Padding(4);
            this.p_soyadi.MaxLength = 25;
            this.p_soyadi.Name = "p_soyadi";
            this.p_soyadi.Size = new System.Drawing.Size(184, 23);
            this.p_soyadi.TabIndex = 3;
            this.p_soyadi.TextChanged += new System.EventHandler(this.p_soyadi_TextChanged);
            // 
            // p_adi
            // 
            this.p_adi.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p_adi.ForeColor = System.Drawing.Color.Black;
            this.p_adi.Location = new System.Drawing.Point(153, 130);
            this.p_adi.Margin = new System.Windows.Forms.Padding(4);
            this.p_adi.MaxLength = 25;
            this.p_adi.Name = "p_adi";
            this.p_adi.Size = new System.Drawing.Size(184, 23);
            this.p_adi.TabIndex = 2;
            this.p_adi.TextChanged += new System.EventHandler(this.p_adi_TextChanged);
            // 
            // k_adi
            // 
            this.k_adi.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.k_adi.Enabled = false;
            this.k_adi.ForeColor = System.Drawing.Color.Black;
            this.k_adi.Location = new System.Drawing.Point(153, 73);
            this.k_adi.Margin = new System.Windows.Forms.Padding(4);
            this.k_adi.MaxLength = 25;
            this.k_adi.Name = "k_adi";
            this.k_adi.Size = new System.Drawing.Size(184, 23);
            this.k_adi.TabIndex = 1;
            this.k_adi.TextChanged += new System.EventHandler(this.k_adi_TextChanged);
            // 
            // e_posta
            // 
            this.e_posta.AutoSize = true;
            this.e_posta.ForeColor = System.Drawing.Color.Black;
            this.e_posta.Location = new System.Drawing.Point(150, 336);
            this.e_posta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e_posta.Name = "e_posta";
            this.e_posta.Size = new System.Drawing.Size(125, 17);
            this.e_posta.TabIndex = 6;
            this.e_posta.Text = "E - Posta adresi";
            // 
            // per_number
            // 
            this.per_number.AutoSize = true;
            this.per_number.ForeColor = System.Drawing.Color.Black;
            this.per_number.Location = new System.Drawing.Point(150, 281);
            this.per_number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.per_number.Name = "per_number";
            this.per_number.Size = new System.Drawing.Size(145, 17);
            this.per_number.TabIndex = 5;
            this.per_number.Text = "Personel Numarası";
            // 
            // tc_kimlik
            // 
            this.tc_kimlik.AutoSize = true;
            this.tc_kimlik.ForeColor = System.Drawing.Color.Black;
            this.tc_kimlik.Location = new System.Drawing.Point(150, 225);
            this.tc_kimlik.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tc_kimlik.Name = "tc_kimlik";
            this.tc_kimlik.Size = new System.Drawing.Size(153, 17);
            this.tc_kimlik.TabIndex = 4;
            this.tc_kimlik.Text = "T.C Kimlik Numarası";
            // 
            // per_soy
            // 
            this.per_soy.AutoSize = true;
            this.per_soy.ForeColor = System.Drawing.Color.Black;
            this.per_soy.Location = new System.Drawing.Point(150, 167);
            this.per_soy.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.per_soy.Name = "per_soy";
            this.per_soy.Size = new System.Drawing.Size(126, 17);
            this.per_soy.TabIndex = 3;
            this.per_soy.Text = "Personel Soyadı";
            // 
            // per_adi
            // 
            this.per_adi.AutoSize = true;
            this.per_adi.ForeColor = System.Drawing.Color.Black;
            this.per_adi.Location = new System.Drawing.Point(150, 109);
            this.per_adi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.per_adi.Name = "per_adi";
            this.per_adi.Size = new System.Drawing.Size(100, 17);
            this.per_adi.TabIndex = 2;
            this.per_adi.Text = "Personel Adı";
            // 
            // kul_adi
            // 
            this.kul_adi.AutoSize = true;
            this.kul_adi.ForeColor = System.Drawing.Color.Black;
            this.kul_adi.Location = new System.Drawing.Point(150, 52);
            this.kul_adi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.kul_adi.Name = "kul_adi";
            this.kul_adi.Size = new System.Drawing.Size(97, 17);
            this.kul_adi.TabIndex = 1;
            this.kul_adi.Text = "Kullanıcı Adı";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // sifirla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 671);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "sifirla";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Şifre Yenile";
            this.Load += new System.EventHandler(this.pass_sıfırla_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label tc_kimlik;
        private System.Windows.Forms.Label per_soy;
        private System.Windows.Forms.Label per_adi;
        private System.Windows.Forms.Label kul_adi;
        private System.Windows.Forms.TextBox p_eposta;
        private System.Windows.Forms.TextBox p_tc;
        private System.Windows.Forms.TextBox p_soyadi;
        private System.Windows.Forms.TextBox p_adi;
        private System.Windows.Forms.TextBox k_adi;
        private System.Windows.Forms.Label e_posta;
        private System.Windows.Forms.Button s_yenile;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox y_tekrar;
        private System.Windows.Forms.TextBox y_sifre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button kapat;
        private System.Windows.Forms.ImageList ımageList2;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.TextBox p_number;
        private System.Windows.Forms.Label per_number;
    }
}