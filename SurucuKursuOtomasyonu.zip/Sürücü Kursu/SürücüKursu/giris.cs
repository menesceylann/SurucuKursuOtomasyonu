﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SürücüKursu
{
    public partial class KullaniciGiris : Form
    {
        OleDbConnection baglanti = new OleDbConnection(@"Provider=Microsoft.Ace.OLEDB.12.0;Data Source=" + Directory.GetCurrentDirectory() + @"\database.accdb");
        OleDbCommand komut = null;
        OleDbDataReader oku = null;
        AnaForm anamenu = new AnaForm();
        sifirla sıfırla = new sifirla();
        public static string kul_adi = null;

        public KullaniciGiris()
        {
            InitializeComponent();
        }

        private void buttonCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void giris()
        {
            baglanti.Open();

            komut = new OleDbCommand("Select * From giris where kul_adi=?", baglanti);
            komut.Parameters.AddWithValue("?", textBox1.Text);
            oku = komut.ExecuteReader();
            if (oku.Read() == false)
            {
                MessageBox.Show("Kullanici adi bulunamadi !!!", "Geçersiz Kullanıcı Girişi", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                textBox1.Text = null;
                textBox2.Text = null;
                kul_adi = null;
            }
            else
            {
                komut = new OleDbCommand("Select * From giris where kul_adi=? and kul_sifre=?", baglanti);
                komut.Parameters.AddWithValue("?", textBox1.Text);
                komut.Parameters.AddWithValue("?", textBox2.Text);
                oku = komut.ExecuteReader();
                if (oku.Read() == true)
                {
                    anamenu.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Şifrenizi Hatalı Girdiniz...", "Geçersiz Kullanıcı Girişi", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    textBox2.Text = null;
                    p_sıfır.Enabled = true;
                    p_sıfır.ForeColor = Color.DarkBlue;
                    kul_adi = textBox1.Text;
                }
            }
            komut.Dispose();
            oku.Close();
            baglanti.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                errorProvider1.SetError(textBox1, "Boş Geçilemez !!!");
                errorProvider1.SetError(textBox2, "Boş Geçilemez !!!");
            }
            else
            {
                giris();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.White;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.White;
        }

        private void p_sıfır_Click(object sender, EventArgs e)
        {
            sıfırla.ShowDialog();
            p_sıfır.Enabled = false;
        }

    }
}

