﻿namespace SürücüKursu
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnaForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.liste_yenile = new System.Windows.Forms.Button();
            this.yenile = new System.Windows.Forms.ImageList(this.components);
            this.buttonPersonelBilgileri = new System.Windows.Forms.Button();
            this.ımageList5 = new System.Windows.Forms.ImageList(this.components);
            this.button_not = new System.Windows.Forms.Button();
            this.ımageList4 = new System.Windows.Forms.ImageList(this.components);
            this.buttonAdayBilgileri = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.buttonCikis = new System.Windows.Forms.Button();
            this.cikis = new System.Windows.Forms.ImageList(this.components);
            this.buttonOdemeler = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.buttonNüfüsBilgileri = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.kursiyer_panel = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.yeni_kayit = new System.Windows.Forms.Button();
            this.yeni = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.b_kaydet = new System.Windows.Forms.Button();
            this.kayit = new System.Windows.Forms.ImageList(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ilçe = new System.Windows.Forms.TextBox();
            this.il = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.nufus_yeni = new System.Windows.Forms.Button();
            this.nufus_kaydet = new System.Windows.Forms.Button();
            this.dogum_tarih = new System.Windows.Forms.DateTimePicker();
            this.kan_grup = new System.Windows.Forms.TextBox();
            this.dogum_yeri = new System.Windows.Forms.TextBox();
            this.ana = new System.Windows.Forms.TextBox();
            this.baba = new System.Windows.Forms.TextBox();
            this.soyad = new System.Windows.Forms.TextBox();
            this.ad = new System.Windows.Forms.TextBox();
            this.tc_kimlik = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.odeme_panel = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.t_borc = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.ödeme_yeni = new System.Windows.Forms.Button();
            this.ödeme_kaydet = new System.Windows.Forms.Button();
            this.odeme_dateTime = new System.Windows.Forms.DateTimePicker();
            this.o_tutar = new System.Windows.Forms.TextBox();
            this.o_tc_kimlik = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.notgirisi_panel = new System.Windows.Forms.Panel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.not_yeni_k = new System.Windows.Forms.Button();
            this.not_bilgi_kaydet = new System.Windows.Forms.Button();
            this.not_ilkyardim = new System.Windows.Forms.TextBox();
            this.not_dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.not_motor = new System.Windows.Forms.TextBox();
            this.not_trafik = new System.Windows.Forms.TextBox();
            this.not_tc = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.personel_panel = new System.Windows.Forms.Panel();
            this.p_yenikayit = new System.Windows.Forms.Button();
            this.p_bilgikaydet = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.GridView2_personel = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.p_görev = new System.Windows.Forms.TextBox();
            this.p_eposta = new System.Windows.Forms.TextBox();
            this.p_telefon = new System.Windows.Forms.TextBox();
            this.p_soyadi = new System.Windows.Forms.TextBox();
            this.p_ad = new System.Windows.Forms.TextBox();
            this.p_tc_kimlik = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.ayarlar_panel = new System.Windows.Forms.Panel();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.per_number = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.sifre_degistir = new System.Windows.Forms.Button();
            this.y_s_tekrar = new System.Windows.Forms.TextBox();
            this.y_sifre = new System.Windows.Forms.TextBox();
            this.m_sifre = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.hata = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.kursiyer_panel.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.odeme_panel.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.notgirisi_panel.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.personel_panel.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2_personel)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.ayarlar_panel.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(3, 4);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.liste_yenile);
            this.splitContainer1.Panel1.Controls.Add(this.buttonPersonelBilgileri);
            this.splitContainer1.Panel1.Controls.Add(this.button_not);
            this.splitContainer1.Panel1.Controls.Add(this.buttonAdayBilgileri);
            this.splitContainer1.Panel1.Controls.Add(this.buttonCikis);
            this.splitContainer1.Panel1.Controls.Add(this.buttonOdemeler);
            this.splitContainer1.Panel1.Controls.Add(this.buttonNüfüsBilgileri);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Panel2.Controls.Add(this.kursiyer_panel);
            this.splitContainer1.Panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.splitContainer1.Size = new System.Drawing.Size(1209, 768);
            this.splitContainer1.SplitterDistance = 82;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 6;
            // 
            // liste_yenile
            // 
            this.liste_yenile.BackColor = System.Drawing.SystemColors.Control;
            this.liste_yenile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.liste_yenile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.liste_yenile.ImageKey = "yenile.png";
            this.liste_yenile.ImageList = this.yenile;
            this.liste_yenile.Location = new System.Drawing.Point(916, 11);
            this.liste_yenile.Margin = new System.Windows.Forms.Padding(4);
            this.liste_yenile.Name = "liste_yenile";
            this.liste_yenile.Size = new System.Drawing.Size(145, 60);
            this.liste_yenile.TabIndex = 6;
            this.liste_yenile.Text = "Listeyi Yenile";
            this.liste_yenile.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.liste_yenile.UseVisualStyleBackColor = false;
            this.liste_yenile.Click += new System.EventHandler(this.liste_yenile_Click);
            // 
            // yenile
            // 
            this.yenile.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("yenile.ImageStream")));
            this.yenile.TransparentColor = System.Drawing.Color.Transparent;
            this.yenile.Images.SetKeyName(0, "yenile.png");
            // 
            // buttonPersonelBilgileri
            // 
            this.buttonPersonelBilgileri.BackColor = System.Drawing.SystemColors.Control;
            this.buttonPersonelBilgileri.Enabled = false;
            this.buttonPersonelBilgileri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPersonelBilgileri.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPersonelBilgileri.ImageKey = "toplum.png";
            this.buttonPersonelBilgileri.ImageList = this.ımageList5;
            this.buttonPersonelBilgileri.Location = new System.Drawing.Point(763, 11);
            this.buttonPersonelBilgileri.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPersonelBilgileri.Name = "buttonPersonelBilgileri";
            this.buttonPersonelBilgileri.Size = new System.Drawing.Size(145, 60);
            this.buttonPersonelBilgileri.TabIndex = 1;
            this.buttonPersonelBilgileri.Text = "PERSONEL BİLGİLERİ";
            this.buttonPersonelBilgileri.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonPersonelBilgileri.UseVisualStyleBackColor = false;
            this.buttonPersonelBilgileri.Click += new System.EventHandler(this.buttonPersonelBilgileri_Click_1);
            // 
            // ımageList5
            // 
            this.ımageList5.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList5.ImageStream")));
            this.ımageList5.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList5.Images.SetKeyName(0, "toplum.png");
            // 
            // button_not
            // 
            this.button_not.BackColor = System.Drawing.SystemColors.Control;
            this.button_not.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_not.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_not.ImageKey = "kalem.jpg";
            this.button_not.ImageList = this.ımageList4;
            this.button_not.Location = new System.Drawing.Point(583, 11);
            this.button_not.Margin = new System.Windows.Forms.Padding(4);
            this.button_not.Name = "button_not";
            this.button_not.Size = new System.Drawing.Size(172, 60);
            this.button_not.TabIndex = 4;
            this.button_not.Text = "NOT BİLGİLERİ";
            this.button_not.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_not.UseVisualStyleBackColor = false;
            this.button_not.Click += new System.EventHandler(this.button_not_Click);
            // 
            // ımageList4
            // 
            this.ımageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList4.ImageStream")));
            this.ımageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList4.Images.SetKeyName(0, "kalem.jpg");
            // 
            // buttonAdayBilgileri
            // 
            this.buttonAdayBilgileri.BackColor = System.Drawing.SystemColors.Control;
            this.buttonAdayBilgileri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAdayBilgileri.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAdayBilgileri.ImageKey = "kisi.png";
            this.buttonAdayBilgileri.ImageList = this.ımageList1;
            this.buttonAdayBilgileri.Location = new System.Drawing.Point(45, 11);
            this.buttonAdayBilgileri.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAdayBilgileri.Name = "buttonAdayBilgileri";
            this.buttonAdayBilgileri.Size = new System.Drawing.Size(176, 60);
            this.buttonAdayBilgileri.TabIndex = 2;
            this.buttonAdayBilgileri.Text = "ADAY BİLGİLERİ";
            this.buttonAdayBilgileri.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAdayBilgileri.UseVisualStyleBackColor = false;
            this.buttonAdayBilgileri.Click += new System.EventHandler(this.buttonAdayBilgileri_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "kisi.png");
            // 
            // buttonCikis
            // 
            this.buttonCikis.BackColor = System.Drawing.SystemColors.Control;
            this.buttonCikis.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCikis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCikis.ImageKey = "cikis.png";
            this.buttonCikis.ImageList = this.cikis;
            this.buttonCikis.Location = new System.Drawing.Point(1067, 11);
            this.buttonCikis.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCikis.Name = "buttonCikis";
            this.buttonCikis.Size = new System.Drawing.Size(111, 60);
            this.buttonCikis.TabIndex = 5;
            this.buttonCikis.Text = "ÇIKIŞ";
            this.buttonCikis.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonCikis.UseVisualStyleBackColor = false;
            this.buttonCikis.Click += new System.EventHandler(this.buttonCikis_Click_1);
            // 
            // cikis
            // 
            this.cikis.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("cikis.ImageStream")));
            this.cikis.TransparentColor = System.Drawing.Color.Transparent;
            this.cikis.Images.SetKeyName(0, "cikis.png");
            // 
            // buttonOdemeler
            // 
            this.buttonOdemeler.BackColor = System.Drawing.SystemColors.Control;
            this.buttonOdemeler.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonOdemeler.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonOdemeler.ImageKey = "para.png";
            this.buttonOdemeler.ImageList = this.ımageList3;
            this.buttonOdemeler.Location = new System.Drawing.Point(424, 11);
            this.buttonOdemeler.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOdemeler.Name = "buttonOdemeler";
            this.buttonOdemeler.Size = new System.Drawing.Size(148, 60);
            this.buttonOdemeler.TabIndex = 0;
            this.buttonOdemeler.Text = "ÖDEMELER";
            this.buttonOdemeler.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonOdemeler.UseVisualStyleBackColor = false;
            this.buttonOdemeler.Click += new System.EventHandler(this.buttonOdemeler_Click_1);
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "para.png");
            // 
            // buttonNüfüsBilgileri
            // 
            this.buttonNüfüsBilgileri.BackColor = System.Drawing.SystemColors.Control;
            this.buttonNüfüsBilgileri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNüfüsBilgileri.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNüfüsBilgileri.ImageKey = "kisi.png";
            this.buttonNüfüsBilgileri.ImageList = this.ımageList2;
            this.buttonNüfüsBilgileri.Location = new System.Drawing.Point(229, 11);
            this.buttonNüfüsBilgileri.Margin = new System.Windows.Forms.Padding(4);
            this.buttonNüfüsBilgileri.Name = "buttonNüfüsBilgileri";
            this.buttonNüfüsBilgileri.Size = new System.Drawing.Size(187, 60);
            this.buttonNüfüsBilgileri.TabIndex = 3;
            this.buttonNüfüsBilgileri.Text = "NÜFUS BİLGİLERİ";
            this.buttonNüfüsBilgileri.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonNüfüsBilgileri.UseVisualStyleBackColor = false;
            this.buttonNüfüsBilgileri.Click += new System.EventHandler(this.buttonNüfüsBilgileri_Click);
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "kisi.png");
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 4);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 4;
            this.dataGridView1.Size = new System.Drawing.Size(1201, 236);
            this.dataGridView1.TabIndex = 1;
            // 
            // kursiyer_panel
            // 
            this.kursiyer_panel.Controls.Add(this.tabPage1);
            this.kursiyer_panel.Controls.Add(this.tabPage2);
            this.kursiyer_panel.Controls.Add(this.tabPage3);
            this.kursiyer_panel.Controls.Add(this.tabPage4);
            this.kursiyer_panel.Controls.Add(this.tabPage5);
            this.kursiyer_panel.Controls.Add(this.tabPage7);
            this.kursiyer_panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kursiyer_panel.Location = new System.Drawing.Point(0, 242);
            this.kursiyer_panel.Margin = new System.Windows.Forms.Padding(4);
            this.kursiyer_panel.Name = "kursiyer_panel";
            this.kursiyer_panel.SelectedIndex = 0;
            this.kursiyer_panel.Size = new System.Drawing.Size(1205, 438);
            this.kursiyer_panel.TabIndex = 0;
            this.kursiyer_panel.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage1.Controls.Add(this.yeni_kayit);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.b_kaydet);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage1.ImageKey = "insan.ico";
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1197, 408);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Kursiyer Kayıt  ";
            // 
            // yeni_kayit
            // 
            this.yeni_kayit.Enabled = false;
            this.yeni_kayit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.yeni_kayit.ImageIndex = 0;
            this.yeni_kayit.ImageList = this.yeni;
            this.yeni_kayit.Location = new System.Drawing.Point(759, 356);
            this.yeni_kayit.Margin = new System.Windows.Forms.Padding(4);
            this.yeni_kayit.Name = "yeni_kayit";
            this.yeni_kayit.Size = new System.Drawing.Size(143, 44);
            this.yeni_kayit.TabIndex = 35;
            this.yeni_kayit.Text = "Yeni Kayıt";
            this.yeni_kayit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.yeni_kayit.UseVisualStyleBackColor = true;
            this.yeni_kayit.Click += new System.EventHandler(this.yeni_kayit_Click);
            // 
            // yeni
            // 
            this.yeni.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("yeni.ImageStream")));
            this.yeni.TransparentColor = System.Drawing.Color.Transparent;
            this.yeni.Images.SetKeyName(0, "yenikayit.png");
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(8, 7);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1179, 341);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(818, 189);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(265, 25);
            this.comboBox4.TabIndex = 38;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(818, 121);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(265, 25);
            this.comboBox3.TabIndex = 37;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(815, 100);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 17);
            this.label22.TabIndex = 36;
            this.label22.Text = "Sınıf Adı";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(815, 168);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 17);
            this.label21.TabIndex = 35;
            this.label21.Text = "Ehliyet Sınıfı";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton4);
            this.groupBox4.Controls.Add(this.radioButton3);
            this.groupBox4.Location = new System.Drawing.Point(412, 168);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(267, 37);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(33, 12);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(54, 21);
            this.radioButton4.TabIndex = 10;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Var";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(173, 12);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(56, 21);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Yok";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Location = new System.Drawing.Point(412, 86);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(267, 37);
            this.groupBox3.TabIndex = 34;
            this.groupBox3.TabStop = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(176, 10);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(56, 21);
            this.radioButton2.TabIndex = 9;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Yok";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(39, 10);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(54, 21);
            this.radioButton1.TabIndex = 8;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Var";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(412, 242);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 23);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(56, 272);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.MaxLength = 11;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(265, 23);
            this.textBox5.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(56, 214);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.MaxLength = 11;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(265, 23);
            this.textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(56, 160);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.MaxLength = 11;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(265, 23);
            this.textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(59, 102);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.MaxLength = 11;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(265, 23);
            this.textBox2.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(409, 147);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 17);
            this.label11.TabIndex = 11;
            this.label11.Text = "Adli Belge";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(409, 65);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "Sağlık Raporu";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(409, 221);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Kayıt Tarihi";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(53, 251);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Telefon";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(56, 193);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Yaş";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(56, 139);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Soyadı";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(56, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "T.C Kimlik Numarası";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(56, 81);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Adı";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(59, 41);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.MaxLength = 11;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(265, 23);
            this.textBox1.TabIndex = 1;
            // 
            // b_kaydet
            // 
            this.b_kaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b_kaydet.ImageIndex = 0;
            this.b_kaydet.ImageList = this.kayit;
            this.b_kaydet.Location = new System.Drawing.Point(989, 356);
            this.b_kaydet.Margin = new System.Windows.Forms.Padding(4);
            this.b_kaydet.Name = "b_kaydet";
            this.b_kaydet.Size = new System.Drawing.Size(185, 44);
            this.b_kaydet.TabIndex = 4;
            this.b_kaydet.Text = "Bilgilerimi Kaydet";
            this.b_kaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.b_kaydet.UseVisualStyleBackColor = true;
            this.b_kaydet.Click += new System.EventHandler(this.b_kaydet_Click);
            // 
            // kayit
            // 
            this.kayit.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("kayit.ImageStream")));
            this.kayit.TransparentColor = System.Drawing.Color.Transparent;
            this.kayit.Images.SetKeyName(0, "kayıt.png");
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage2.ImageKey = "imagesCAATEUEE.png";
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1197, 408);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Kişisel Bilgileri";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LightGray;
            this.groupBox5.Controls.Add(this.ilçe);
            this.groupBox5.Controls.Add(this.il);
            this.groupBox5.Controls.Add(this.label54);
            this.groupBox5.Controls.Add(this.label53);
            this.groupBox5.Controls.Add(this.nufus_yeni);
            this.groupBox5.Controls.Add(this.nufus_kaydet);
            this.groupBox5.Controls.Add(this.dogum_tarih);
            this.groupBox5.Controls.Add(this.kan_grup);
            this.groupBox5.Controls.Add(this.dogum_yeri);
            this.groupBox5.Controls.Add(this.ana);
            this.groupBox5.Controls.Add(this.baba);
            this.groupBox5.Controls.Add(this.soyad);
            this.groupBox5.Controls.Add(this.ad);
            this.groupBox5.Controls.Add(this.tc_kimlik);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox5.Location = new System.Drawing.Point(4, 7);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1183, 370);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // ilçe
            // 
            this.ilçe.Location = new System.Drawing.Point(319, 288);
            this.ilçe.Margin = new System.Windows.Forms.Padding(4);
            this.ilçe.MaxLength = 25;
            this.ilçe.Name = "ilçe";
            this.ilçe.Size = new System.Drawing.Size(199, 23);
            this.ilçe.TabIndex = 50;
            // 
            // il
            // 
            this.il.Location = new System.Drawing.Point(319, 230);
            this.il.Margin = new System.Windows.Forms.Padding(4);
            this.il.MaxLength = 25;
            this.il.Name = "il";
            this.il.Size = new System.Drawing.Size(199, 23);
            this.il.TabIndex = 49;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label54.Location = new System.Drawing.Point(316, 267);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(33, 17);
            this.label54.TabIndex = 46;
            this.label54.Text = "İlçe";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label53.Location = new System.Drawing.Point(316, 209);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(16, 17);
            this.label53.TabIndex = 45;
            this.label53.Text = "İl";
            // 
            // nufus_yeni
            // 
            this.nufus_yeni.Enabled = false;
            this.nufus_yeni.ForeColor = System.Drawing.Color.Black;
            this.nufus_yeni.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nufus_yeni.ImageIndex = 0;
            this.nufus_yeni.ImageList = this.yeni;
            this.nufus_yeni.Location = new System.Drawing.Point(757, 36);
            this.nufus_yeni.Margin = new System.Windows.Forms.Padding(4);
            this.nufus_yeni.Name = "nufus_yeni";
            this.nufus_yeni.Size = new System.Drawing.Size(143, 44);
            this.nufus_yeni.TabIndex = 41;
            this.nufus_yeni.Text = "Yeni Kayıt";
            this.nufus_yeni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nufus_yeni.UseVisualStyleBackColor = true;
            this.nufus_yeni.Click += new System.EventHandler(this.nufus_yeni_Click);
            // 
            // nufus_kaydet
            // 
            this.nufus_kaydet.ForeColor = System.Drawing.Color.Black;
            this.nufus_kaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nufus_kaydet.ImageIndex = 0;
            this.nufus_kaydet.ImageList = this.kayit;
            this.nufus_kaydet.Location = new System.Drawing.Point(715, 267);
            this.nufus_kaydet.Margin = new System.Windows.Forms.Padding(4);
            this.nufus_kaydet.Name = "nufus_kaydet";
            this.nufus_kaydet.Size = new System.Drawing.Size(185, 44);
            this.nufus_kaydet.TabIndex = 40;
            this.nufus_kaydet.Text = "Bilgilerimi Kaydet";
            this.nufus_kaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nufus_kaydet.UseVisualStyleBackColor = true;
            this.nufus_kaydet.Click += new System.EventHandler(this.nufus_kaydet_Click);
            // 
            // dogum_tarih
            // 
            this.dogum_tarih.Location = new System.Drawing.Point(319, 113);
            this.dogum_tarih.Margin = new System.Windows.Forms.Padding(4);
            this.dogum_tarih.Name = "dogum_tarih";
            this.dogum_tarih.Size = new System.Drawing.Size(199, 23);
            this.dogum_tarih.TabIndex = 40;
            // 
            // kan_grup
            // 
            this.kan_grup.Location = new System.Drawing.Point(319, 172);
            this.kan_grup.Margin = new System.Windows.Forms.Padding(4);
            this.kan_grup.Name = "kan_grup";
            this.kan_grup.Size = new System.Drawing.Size(199, 23);
            this.kan_grup.TabIndex = 32;
            // 
            // dogum_yeri
            // 
            this.dogum_yeri.Location = new System.Drawing.Point(319, 57);
            this.dogum_yeri.Margin = new System.Windows.Forms.Padding(4);
            this.dogum_yeri.MaxLength = 25;
            this.dogum_yeri.Name = "dogum_yeri";
            this.dogum_yeri.Size = new System.Drawing.Size(199, 23);
            this.dogum_yeri.TabIndex = 28;
            // 
            // ana
            // 
            this.ana.Location = new System.Drawing.Point(37, 288);
            this.ana.Margin = new System.Windows.Forms.Padding(4);
            this.ana.MaxLength = 25;
            this.ana.Name = "ana";
            this.ana.Size = new System.Drawing.Size(199, 23);
            this.ana.TabIndex = 27;
            // 
            // baba
            // 
            this.baba.Location = new System.Drawing.Point(37, 230);
            this.baba.Margin = new System.Windows.Forms.Padding(4);
            this.baba.MaxLength = 25;
            this.baba.Name = "baba";
            this.baba.Size = new System.Drawing.Size(199, 23);
            this.baba.TabIndex = 26;
            // 
            // soyad
            // 
            this.soyad.Location = new System.Drawing.Point(37, 172);
            this.soyad.Margin = new System.Windows.Forms.Padding(4);
            this.soyad.MaxLength = 25;
            this.soyad.Name = "soyad";
            this.soyad.Size = new System.Drawing.Size(199, 23);
            this.soyad.TabIndex = 25;
            // 
            // ad
            // 
            this.ad.Location = new System.Drawing.Point(37, 113);
            this.ad.Margin = new System.Windows.Forms.Padding(4);
            this.ad.MaxLength = 25;
            this.ad.Name = "ad";
            this.ad.Size = new System.Drawing.Size(199, 23);
            this.ad.TabIndex = 24;
            // 
            // tc_kimlik
            // 
            this.tc_kimlik.Location = new System.Drawing.Point(37, 56);
            this.tc_kimlik.Margin = new System.Windows.Forms.Padding(4);
            this.tc_kimlik.MaxLength = 11;
            this.tc_kimlik.Name = "tc_kimlik";
            this.tc_kimlik.Size = new System.Drawing.Size(199, 23);
            this.tc_kimlik.TabIndex = 23;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label41.Location = new System.Drawing.Point(316, 151);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 17);
            this.label41.TabIndex = 11;
            this.label41.Text = "Kan Grubu";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(316, 92);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(105, 17);
            this.label39.TabIndex = 9;
            this.label39.Text = "Dogum Tarihi";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label36.Location = new System.Drawing.Point(316, 35);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(92, 17);
            this.label36.TabIndex = 6;
            this.label36.Text = "Doğum Yeri";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label35.Location = new System.Drawing.Point(34, 267);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 17);
            this.label35.TabIndex = 5;
            this.label35.Text = "Ana Adı";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label34.Location = new System.Drawing.Point(34, 209);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(73, 17);
            this.label34.TabIndex = 4;
            this.label34.Text = "Baba Adı";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label33.Location = new System.Drawing.Point(34, 151);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 17);
            this.label33.TabIndex = 3;
            this.label33.Text = "Soyadı";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label32.Location = new System.Drawing.Point(34, 92);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 17);
            this.label32.TabIndex = 2;
            this.label32.Text = "Adı";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(34, 35);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(158, 17);
            this.label31.TabIndex = 1;
            this.label31.Text = "T.C. Kimlik Numarası";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tabPage3.Controls.Add(this.odeme_panel);
            this.tabPage3.ImageIndex = 6;
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1197, 408);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Ödeme Girişi ";
            // 
            // odeme_panel
            // 
            this.odeme_panel.Controls.Add(this.groupBox7);
            this.odeme_panel.Location = new System.Drawing.Point(0, 4);
            this.odeme_panel.Margin = new System.Windows.Forms.Padding(4);
            this.odeme_panel.Name = "odeme_panel";
            this.odeme_panel.Size = new System.Drawing.Size(1195, 382);
            this.odeme_panel.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.LightGray;
            this.groupBox7.Controls.Add(this.t_borc);
            this.groupBox7.Controls.Add(this.label104);
            this.groupBox7.Controls.Add(this.ödeme_yeni);
            this.groupBox7.Controls.Add(this.ödeme_kaydet);
            this.groupBox7.Controls.Add(this.odeme_dateTime);
            this.groupBox7.Controls.Add(this.o_tutar);
            this.groupBox7.Controls.Add(this.o_tc_kimlik);
            this.groupBox7.Controls.Add(this.label77);
            this.groupBox7.Controls.Add(this.label76);
            this.groupBox7.Controls.Add(this.label75);
            this.groupBox7.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox7.Location = new System.Drawing.Point(8, 4);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(1189, 359);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            // 
            // t_borc
            // 
            this.t_borc.Location = new System.Drawing.Point(308, 185);
            this.t_borc.Margin = new System.Windows.Forms.Padding(4);
            this.t_borc.MaxLength = 10;
            this.t_borc.Name = "t_borc";
            this.t_borc.Size = new System.Drawing.Size(239, 23);
            this.t_borc.TabIndex = 16;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.ForeColor = System.Drawing.Color.Black;
            this.label104.Location = new System.Drawing.Point(305, 164);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(99, 17);
            this.label104.TabIndex = 14;
            this.label104.Text = "Toplam Borç";
            // 
            // ödeme_yeni
            // 
            this.ödeme_yeni.Enabled = false;
            this.ödeme_yeni.ForeColor = System.Drawing.Color.Black;
            this.ödeme_yeni.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ödeme_yeni.ImageIndex = 0;
            this.ödeme_yeni.ImageList = this.yeni;
            this.ödeme_yeni.Location = new System.Drawing.Point(805, 195);
            this.ödeme_yeni.Margin = new System.Windows.Forms.Padding(4);
            this.ödeme_yeni.Name = "ödeme_yeni";
            this.ödeme_yeni.Size = new System.Drawing.Size(143, 44);
            this.ödeme_yeni.TabIndex = 5;
            this.ödeme_yeni.Text = "Yeni Kayıt";
            this.ödeme_yeni.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ödeme_yeni.UseVisualStyleBackColor = true;
            this.ödeme_yeni.Click += new System.EventHandler(this.ödeme_yeni_Click);
            // 
            // ödeme_kaydet
            // 
            this.ödeme_kaydet.ForeColor = System.Drawing.Color.Black;
            this.ödeme_kaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ödeme_kaydet.ImageIndex = 0;
            this.ödeme_kaydet.ImageList = this.kayit;
            this.ödeme_kaydet.Location = new System.Drawing.Point(763, 80);
            this.ödeme_kaydet.Margin = new System.Windows.Forms.Padding(4);
            this.ödeme_kaydet.Name = "ödeme_kaydet";
            this.ödeme_kaydet.Size = new System.Drawing.Size(185, 44);
            this.ödeme_kaydet.TabIndex = 4;
            this.ödeme_kaydet.Text = "Bilgilerimi Kaydet";
            this.ödeme_kaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ödeme_kaydet.UseVisualStyleBackColor = true;
            this.ödeme_kaydet.Click += new System.EventHandler(this.ödeme_kaydet_Click);
            // 
            // odeme_dateTime
            // 
            this.odeme_dateTime.Location = new System.Drawing.Point(308, 128);
            this.odeme_dateTime.Margin = new System.Windows.Forms.Padding(4);
            this.odeme_dateTime.Name = "odeme_dateTime";
            this.odeme_dateTime.Size = new System.Drawing.Size(239, 23);
            this.odeme_dateTime.TabIndex = 2;
            // 
            // o_tutar
            // 
            this.o_tutar.Location = new System.Drawing.Point(308, 243);
            this.o_tutar.Margin = new System.Windows.Forms.Padding(4);
            this.o_tutar.MaxLength = 10;
            this.o_tutar.Name = "o_tutar";
            this.o_tutar.Size = new System.Drawing.Size(239, 23);
            this.o_tutar.TabIndex = 3;
            // 
            // o_tc_kimlik
            // 
            this.o_tc_kimlik.Location = new System.Drawing.Point(308, 77);
            this.o_tc_kimlik.Margin = new System.Windows.Forms.Padding(4);
            this.o_tc_kimlik.MaxLength = 11;
            this.o_tc_kimlik.Name = "o_tc_kimlik";
            this.o_tc_kimlik.Size = new System.Drawing.Size(239, 23);
            this.o_tc_kimlik.TabIndex = 1;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.ForeColor = System.Drawing.Color.Black;
            this.label77.Location = new System.Drawing.Point(305, 222);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(107, 17);
            this.label77.TabIndex = 3;
            this.label77.Text = "Ödeme Tutarı";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.ForeColor = System.Drawing.Color.Black;
            this.label76.Location = new System.Drawing.Point(305, 107);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(106, 17);
            this.label76.TabIndex = 2;
            this.label76.Text = "Ödeme Tarihi";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(305, 56);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(153, 17);
            this.label75.TabIndex = 1;
            this.label75.Text = "T.C Kimlik Numarası";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.notgirisi_panel);
            this.tabPage4.ImageIndex = 7;
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1197, 408);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Not Girişi ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // notgirisi_panel
            // 
            this.notgirisi_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.notgirisi_panel.Controls.Add(this.groupBox8);
            this.notgirisi_panel.Location = new System.Drawing.Point(-5, 4);
            this.notgirisi_panel.Margin = new System.Windows.Forms.Padding(4);
            this.notgirisi_panel.Name = "notgirisi_panel";
            this.notgirisi_panel.Size = new System.Drawing.Size(1205, 383);
            this.notgirisi_panel.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.LightGray;
            this.groupBox8.Controls.Add(this.not_yeni_k);
            this.groupBox8.Controls.Add(this.not_bilgi_kaydet);
            this.groupBox8.Controls.Add(this.not_ilkyardim);
            this.groupBox8.Controls.Add(this.not_dateTimePicker2);
            this.groupBox8.Controls.Add(this.label93);
            this.groupBox8.Controls.Add(this.label92);
            this.groupBox8.Controls.Add(this.not_motor);
            this.groupBox8.Controls.Add(this.not_trafik);
            this.groupBox8.Controls.Add(this.not_tc);
            this.groupBox8.Controls.Add(this.label90);
            this.groupBox8.Controls.Add(this.label89);
            this.groupBox8.Controls.Add(this.label88);
            this.groupBox8.Location = new System.Drawing.Point(13, 4);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(1197, 372);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            // 
            // not_yeni_k
            // 
            this.not_yeni_k.Enabled = false;
            this.not_yeni_k.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.not_yeni_k.ImageIndex = 0;
            this.not_yeni_k.ImageList = this.yeni;
            this.not_yeni_k.Location = new System.Drawing.Point(810, 91);
            this.not_yeni_k.Margin = new System.Windows.Forms.Padding(4);
            this.not_yeni_k.Name = "not_yeni_k";
            this.not_yeni_k.Size = new System.Drawing.Size(143, 44);
            this.not_yeni_k.TabIndex = 17;
            this.not_yeni_k.Text = "Yeni Kayıt";
            this.not_yeni_k.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.not_yeni_k.UseVisualStyleBackColor = true;
            this.not_yeni_k.Click += new System.EventHandler(this.not_yeni_k_Click);
            // 
            // not_bilgi_kaydet
            // 
            this.not_bilgi_kaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.not_bilgi_kaydet.ImageIndex = 0;
            this.not_bilgi_kaydet.ImageList = this.kayit;
            this.not_bilgi_kaydet.Location = new System.Drawing.Point(768, 218);
            this.not_bilgi_kaydet.Margin = new System.Windows.Forms.Padding(4);
            this.not_bilgi_kaydet.Name = "not_bilgi_kaydet";
            this.not_bilgi_kaydet.Size = new System.Drawing.Size(185, 44);
            this.not_bilgi_kaydet.TabIndex = 16;
            this.not_bilgi_kaydet.Text = "Bilgilerimi Kaydet";
            this.not_bilgi_kaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.not_bilgi_kaydet.UseVisualStyleBackColor = true;
            this.not_bilgi_kaydet.Click += new System.EventHandler(this.not_bilgi_kaydet_Click);
            // 
            // not_ilkyardim
            // 
            this.not_ilkyardim.Location = new System.Drawing.Point(322, 280);
            this.not_ilkyardim.Margin = new System.Windows.Forms.Padding(4);
            this.not_ilkyardim.MaxLength = 3;
            this.not_ilkyardim.Name = "not_ilkyardim";
            this.not_ilkyardim.Size = new System.Drawing.Size(199, 23);
            this.not_ilkyardim.TabIndex = 15;
            // 
            // not_dateTimePicker2
            // 
            this.not_dateTimePicker2.Location = new System.Drawing.Point(322, 110);
            this.not_dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.not_dateTimePicker2.Name = "not_dateTimePicker2";
            this.not_dateTimePicker2.Size = new System.Drawing.Size(199, 23);
            this.not_dateTimePicker2.TabIndex = 14;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(320, 89);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(95, 17);
            this.label93.TabIndex = 9;
            this.label93.Text = "Sınav Tarihi";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(319, 30);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(153, 17);
            this.label92.TabIndex = 8;
            this.label92.Text = "T.C Kimlik Numarası";
            // 
            // not_motor
            // 
            this.not_motor.Location = new System.Drawing.Point(322, 223);
            this.not_motor.Margin = new System.Windows.Forms.Padding(4);
            this.not_motor.MaxLength = 3;
            this.not_motor.Name = "not_motor";
            this.not_motor.Size = new System.Drawing.Size(199, 23);
            this.not_motor.TabIndex = 6;
            // 
            // not_trafik
            // 
            this.not_trafik.Location = new System.Drawing.Point(322, 166);
            this.not_trafik.Margin = new System.Windows.Forms.Padding(4);
            this.not_trafik.MaxLength = 3;
            this.not_trafik.Name = "not_trafik";
            this.not_trafik.Size = new System.Drawing.Size(199, 23);
            this.not_trafik.TabIndex = 5;
            // 
            // not_tc
            // 
            this.not_tc.Location = new System.Drawing.Point(323, 51);
            this.not_tc.Margin = new System.Windows.Forms.Padding(4);
            this.not_tc.Name = "not_tc";
            this.not_tc.Size = new System.Drawing.Size(199, 23);
            this.not_tc.TabIndex = 4;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(320, 259);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(163, 17);
            this.label90.TabIndex = 3;
            this.label90.Text = "İlk Yardım Sınav Notu";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(319, 202);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(133, 17);
            this.label89.TabIndex = 2;
            this.label89.Text = "Motor Sınav Notu";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(320, 145);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(138, 17);
            this.label88.TabIndex = 1;
            this.label88.Text = "Trafik Sınavi Notu";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.personel_panel);
            this.tabPage5.ImageKey = "personel.ico";
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1197, 408);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Personel Bilgi ve Kayıt ";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // personel_panel
            // 
            this.personel_panel.BackColor = System.Drawing.Color.LightGray;
            this.personel_panel.Controls.Add(this.p_yenikayit);
            this.personel_panel.Controls.Add(this.p_bilgikaydet);
            this.personel_panel.Controls.Add(this.groupBox10);
            this.personel_panel.Controls.Add(this.groupBox9);
            this.personel_panel.Location = new System.Drawing.Point(-1, 4);
            this.personel_panel.Margin = new System.Windows.Forms.Padding(4);
            this.personel_panel.Name = "personel_panel";
            this.personel_panel.Size = new System.Drawing.Size(1196, 386);
            this.personel_panel.TabIndex = 0;
            // 
            // p_yenikayit
            // 
            this.p_yenikayit.Enabled = false;
            this.p_yenikayit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.p_yenikayit.ImageIndex = 0;
            this.p_yenikayit.ImageList = this.yeni;
            this.p_yenikayit.Location = new System.Drawing.Point(396, 329);
            this.p_yenikayit.Margin = new System.Windows.Forms.Padding(4);
            this.p_yenikayit.Name = "p_yenikayit";
            this.p_yenikayit.Size = new System.Drawing.Size(143, 44);
            this.p_yenikayit.TabIndex = 26;
            this.p_yenikayit.Text = "Yeni Kayıt";
            this.p_yenikayit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.p_yenikayit.UseVisualStyleBackColor = true;
            this.p_yenikayit.Click += new System.EventHandler(this.p_yenikayit_Click);
            // 
            // p_bilgikaydet
            // 
            this.p_bilgikaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.p_bilgikaydet.ImageIndex = 0;
            this.p_bilgikaydet.ImageList = this.kayit;
            this.p_bilgikaydet.Location = new System.Drawing.Point(547, 329);
            this.p_bilgikaydet.Margin = new System.Windows.Forms.Padding(4);
            this.p_bilgikaydet.Name = "p_bilgikaydet";
            this.p_bilgikaydet.Size = new System.Drawing.Size(185, 44);
            this.p_bilgikaydet.TabIndex = 25;
            this.p_bilgikaydet.Text = "Bilgilerimi Kaydet";
            this.p_bilgikaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.p_bilgikaydet.UseVisualStyleBackColor = true;
            this.p_bilgikaydet.Click += new System.EventHandler(this.p_bilgikaydet_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.LightGray;
            this.groupBox10.Controls.Add(this.GridView2_personel);
            this.groupBox10.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox10.Location = new System.Drawing.Point(396, 4);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(796, 318);
            this.groupBox10.TabIndex = 24;
            this.groupBox10.TabStop = false;
            // 
            // GridView2_personel
            // 
            this.GridView2_personel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridView2_personel.Location = new System.Drawing.Point(8, 22);
            this.GridView2_personel.Margin = new System.Windows.Forms.Padding(4);
            this.GridView2_personel.Name = "GridView2_personel";
            this.GridView2_personel.RowHeadersWidth = 51;
            this.GridView2_personel.Size = new System.Drawing.Size(780, 288);
            this.GridView2_personel.TabIndex = 1;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.LightGray;
            this.groupBox9.Controls.Add(this.p_görev);
            this.groupBox9.Controls.Add(this.p_eposta);
            this.groupBox9.Controls.Add(this.p_telefon);
            this.groupBox9.Controls.Add(this.p_soyadi);
            this.groupBox9.Controls.Add(this.p_ad);
            this.groupBox9.Controls.Add(this.p_tc_kimlik);
            this.groupBox9.Controls.Add(this.label105);
            this.groupBox9.Controls.Add(this.label102);
            this.groupBox9.Controls.Add(this.label101);
            this.groupBox9.Controls.Add(this.label100);
            this.groupBox9.Controls.Add(this.label99);
            this.groupBox9.Controls.Add(this.label98);
            this.groupBox9.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox9.Location = new System.Drawing.Point(5, 4);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(369, 378);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // p_görev
            // 
            this.p_görev.Location = new System.Drawing.Point(63, 331);
            this.p_görev.Margin = new System.Windows.Forms.Padding(4);
            this.p_görev.Name = "p_görev";
            this.p_görev.Size = new System.Drawing.Size(199, 23);
            this.p_görev.TabIndex = 23;
            // 
            // p_eposta
            // 
            this.p_eposta.Location = new System.Drawing.Point(63, 269);
            this.p_eposta.Margin = new System.Windows.Forms.Padding(4);
            this.p_eposta.Name = "p_eposta";
            this.p_eposta.Size = new System.Drawing.Size(199, 23);
            this.p_eposta.TabIndex = 21;
            // 
            // p_telefon
            // 
            this.p_telefon.Location = new System.Drawing.Point(63, 212);
            this.p_telefon.Margin = new System.Windows.Forms.Padding(4);
            this.p_telefon.MaxLength = 11;
            this.p_telefon.Name = "p_telefon";
            this.p_telefon.Size = new System.Drawing.Size(199, 23);
            this.p_telefon.TabIndex = 19;
            // 
            // p_soyadi
            // 
            this.p_soyadi.Location = new System.Drawing.Point(63, 155);
            this.p_soyadi.Margin = new System.Windows.Forms.Padding(4);
            this.p_soyadi.MaxLength = 25;
            this.p_soyadi.Name = "p_soyadi";
            this.p_soyadi.Size = new System.Drawing.Size(199, 23);
            this.p_soyadi.TabIndex = 18;
            // 
            // p_ad
            // 
            this.p_ad.Location = new System.Drawing.Point(63, 98);
            this.p_ad.Margin = new System.Windows.Forms.Padding(4);
            this.p_ad.MaxLength = 25;
            this.p_ad.Name = "p_ad";
            this.p_ad.Size = new System.Drawing.Size(199, 23);
            this.p_ad.TabIndex = 17;
            // 
            // p_tc_kimlik
            // 
            this.p_tc_kimlik.Location = new System.Drawing.Point(63, 42);
            this.p_tc_kimlik.Name = "p_tc_kimlik";
            this.p_tc_kimlik.Size = new System.Drawing.Size(199, 23);
            this.p_tc_kimlik.TabIndex = 24;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.ForeColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(60, 310);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(61, 17);
            this.label105.TabIndex = 7;
            this.label105.Text = "Görevi ";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.ForeColor = System.Drawing.Color.Black;
            this.label102.Location = new System.Drawing.Point(60, 248);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(65, 17);
            this.label102.TabIndex = 4;
            this.label102.Text = "E-Posta";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.ForeColor = System.Drawing.Color.Black;
            this.label101.Location = new System.Drawing.Point(60, 191);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(63, 17);
            this.label101.TabIndex = 3;
            this.label101.Text = "Telefon";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.ForeColor = System.Drawing.Color.Black;
            this.label100.Location = new System.Drawing.Point(60, 134);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(57, 17);
            this.label100.TabIndex = 2;
            this.label100.Text = "Soyadı";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.ForeColor = System.Drawing.Color.Black;
            this.label99.Location = new System.Drawing.Point(60, 77);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(31, 17);
            this.label99.TabIndex = 1;
            this.label99.Text = "Adı";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.ForeColor = System.Drawing.Color.Black;
            this.label98.Location = new System.Drawing.Point(60, 22);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(153, 17);
            this.label98.TabIndex = 0;
            this.label98.Text = "T.C Kimlik Numarası";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.LightGray;
            this.tabPage7.Controls.Add(this.ayarlar_panel);
            this.tabPage7.ImageKey = "iphone_ayarlar_icon.png";
            this.tabPage7.Location = new System.Drawing.Point(4, 26);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1197, 408);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Ayarlar";
            // 
            // ayarlar_panel
            // 
            this.ayarlar_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ayarlar_panel.Controls.Add(this.groupBox14);
            this.ayarlar_panel.Location = new System.Drawing.Point(-1, 4);
            this.ayarlar_panel.Margin = new System.Windows.Forms.Padding(4);
            this.ayarlar_panel.Name = "ayarlar_panel";
            this.ayarlar_panel.Size = new System.Drawing.Size(1205, 382);
            this.ayarlar_panel.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.LightGray;
            this.groupBox14.Controls.Add(this.button2);
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox14.Location = new System.Drawing.Point(0, 0);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(1196, 378);
            this.groupBox14.TabIndex = 0;
            this.groupBox14.TabStop = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.ImageKey = "cikis.png";
            this.button2.ImageList = this.cikis;
            this.button2.Location = new System.Drawing.Point(1085, 321);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 49);
            this.button2.TabIndex = 6;
            this.button2.Text = "ÇIKIŞ";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.BackColor = System.Drawing.Color.LightGray;
            this.groupBox15.Controls.Add(this.per_number);
            this.groupBox15.Controls.Add(this.label120);
            this.groupBox15.Controls.Add(this.sifre_degistir);
            this.groupBox15.Controls.Add(this.y_s_tekrar);
            this.groupBox15.Controls.Add(this.y_sifre);
            this.groupBox15.Controls.Add(this.m_sifre);
            this.groupBox15.Controls.Add(this.label115);
            this.groupBox15.Controls.Add(this.label114);
            this.groupBox15.Controls.Add(this.label87);
            this.groupBox15.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox15.Location = new System.Drawing.Point(365, 4);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(459, 366);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            // 
            // per_number
            // 
            this.per_number.Location = new System.Drawing.Point(140, 65);
            this.per_number.Margin = new System.Windows.Forms.Padding(4);
            this.per_number.MaxLength = 9;
            this.per_number.Name = "per_number";
            this.per_number.Size = new System.Drawing.Size(177, 23);
            this.per_number.TabIndex = 1;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.ForeColor = System.Drawing.Color.Black;
            this.label120.Location = new System.Drawing.Point(137, 44);
            this.label120.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(145, 17);
            this.label120.TabIndex = 26;
            this.label120.Text = "Personel Numarası";
            // 
            // sifre_degistir
            // 
            this.sifre_degistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre_degistir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sifre_degistir.ImageIndex = 0;
            this.sifre_degistir.ImageList = this.yenile;
            this.sifre_degistir.Location = new System.Drawing.Point(140, 295);
            this.sifre_degistir.Margin = new System.Windows.Forms.Padding(4);
            this.sifre_degistir.Name = "sifre_degistir";
            this.sifre_degistir.Size = new System.Drawing.Size(175, 49);
            this.sifre_degistir.TabIndex = 5;
            this.sifre_degistir.Text = "Şifremi Değiştir";
            this.sifre_degistir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sifre_degistir.UseVisualStyleBackColor = true;
            this.sifre_degistir.Click += new System.EventHandler(this.sifre_degistir_Click);
            // 
            // y_s_tekrar
            // 
            this.y_s_tekrar.Location = new System.Drawing.Point(140, 221);
            this.y_s_tekrar.Margin = new System.Windows.Forms.Padding(4);
            this.y_s_tekrar.MaxLength = 8;
            this.y_s_tekrar.Name = "y_s_tekrar";
            this.y_s_tekrar.Size = new System.Drawing.Size(177, 23);
            this.y_s_tekrar.TabIndex = 4;
            this.y_s_tekrar.UseSystemPasswordChar = true;
            // 
            // y_sifre
            // 
            this.y_sifre.Location = new System.Drawing.Point(140, 173);
            this.y_sifre.Margin = new System.Windows.Forms.Padding(4);
            this.y_sifre.MaxLength = 8;
            this.y_sifre.Name = "y_sifre";
            this.y_sifre.Size = new System.Drawing.Size(177, 23);
            this.y_sifre.TabIndex = 3;
            this.y_sifre.UseSystemPasswordChar = true;
            // 
            // m_sifre
            // 
            this.m_sifre.Location = new System.Drawing.Point(140, 123);
            this.m_sifre.Margin = new System.Windows.Forms.Padding(4);
            this.m_sifre.MaxLength = 8;
            this.m_sifre.Name = "m_sifre";
            this.m_sifre.Size = new System.Drawing.Size(177, 23);
            this.m_sifre.TabIndex = 2;
            this.m_sifre.UseSystemPasswordChar = true;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.ForeColor = System.Drawing.Color.Black;
            this.label115.Location = new System.Drawing.Point(137, 200);
            this.label115.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(171, 17);
            this.label115.TabIndex = 3;
            this.label115.Text = "Yeni Şifreyi Tekrar Gir";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.ForeColor = System.Drawing.Color.Black;
            this.label114.Location = new System.Drawing.Point(137, 152);
            this.label114.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(79, 17);
            this.label114.TabIndex = 2;
            this.label114.Text = "Yeni Şifre";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.ForeColor = System.Drawing.Color.Black;
            this.label87.Location = new System.Drawing.Point(137, 102);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(77, 17);
            this.label87.TabIndex = 1;
            this.label87.Text = "Eski Şifre";
            // 
            // hata
            // 
            this.hata.ContainerControl = this;
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1215, 775);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "AnaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DÜT DÜT SÜRÜCÜ KURSU ";
            this.Load += new System.EventHandler(this.AnaForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.kursiyer_panel.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.odeme_panel.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.notgirisi_panel.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.personel_panel.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridView2_personel)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.ayarlar_panel.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAdayBilgileri;
        private System.Windows.Forms.Button buttonNüfüsBilgileri;
        private System.Windows.Forms.Button buttonOdemeler;
        private System.Windows.Forms.Button buttonPersonelBilgileri;
        private System.Windows.Forms.Button buttonCikis;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button_not;
        private System.Windows.Forms.TabControl kursiyer_panel;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button b_kaydet;
        private System.Windows.Forms.ErrorProvider hata;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button yeni_kayit;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox kan_grup;
        private System.Windows.Forms.TextBox dogum_yeri;
        private System.Windows.Forms.TextBox ana;
        private System.Windows.Forms.TextBox baba;
        private System.Windows.Forms.TextBox soyad;
        private System.Windows.Forms.TextBox ad;
        private System.Windows.Forms.TextBox tc_kimlik;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dogum_tarih;
        private System.Windows.Forms.Button nufus_yeni;
        private System.Windows.Forms.Button nufus_kaydet;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel odeme_panel;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox o_tutar;
        private System.Windows.Forms.TextBox o_tc_kimlik;
        private System.Windows.Forms.Button ödeme_yeni;
        private System.Windows.Forms.Button ödeme_kaydet;
        private System.Windows.Forms.DateTimePicker odeme_dateTime;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Panel ayarlar_panel;
        private System.Windows.Forms.Panel notgirisi_panel;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox not_motor;
        private System.Windows.Forms.TextBox not_trafik;
        private System.Windows.Forms.TextBox not_tc;
        private System.Windows.Forms.TextBox not_ilkyardim;
        private System.Windows.Forms.DateTimePicker not_dateTimePicker2;
        private System.Windows.Forms.Button not_yeni_k;
        private System.Windows.Forms.Button not_bilgi_kaydet;
        private System.Windows.Forms.Panel personel_panel;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox p_tc_kimlik;
        private System.Windows.Forms.TextBox p_görev;
        private System.Windows.Forms.TextBox p_eposta;
        private System.Windows.Forms.TextBox p_telefon;
        private System.Windows.Forms.TextBox p_soyadi;
        private System.Windows.Forms.TextBox p_ad;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.DataGridView GridView2_personel;
        private System.Windows.Forms.Button p_yenikayit;
        private System.Windows.Forms.Button p_bilgikaydet;
        private System.Windows.Forms.Button liste_yenile;
        private System.Windows.Forms.TextBox t_borc;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox y_s_tekrar;
        private System.Windows.Forms.TextBox y_sifre;
        private System.Windows.Forms.TextBox m_sifre;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button sifre_degistir;
        private System.Windows.Forms.TextBox per_number;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.ImageList yenile;
        private System.Windows.Forms.ImageList ımageList5;
        private System.Windows.Forms.ImageList ımageList4;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.ImageList cikis;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.ImageList ımageList2;
        private System.Windows.Forms.ImageList yeni;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ImageList kayit;
        private System.Windows.Forms.TextBox ilçe;
        private System.Windows.Forms.TextBox il;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
    }
}