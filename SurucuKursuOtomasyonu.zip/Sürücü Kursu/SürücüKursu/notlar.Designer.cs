﻿namespace SürücüKursu
{
    partial class notlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(notlar));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.buttonGüncelle = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.buttonCikis = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.buttonSil = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.not_ilkyardim = new System.Windows.Forms.TextBox();
            this.not_dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.not_motor = new System.Windows.Forms.TextBox();
            this.not_trafik = new System.Windows.Forms.TextBox();
            this.not_tc = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.hata = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(985, 135);
            this.dataGridView1.TabIndex = 6;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.buttonGüncelle);
            this.groupBox8.Controls.Add(this.buttonCikis);
            this.groupBox8.Controls.Add(this.buttonSil);
            this.groupBox8.Controls.Add(this.not_ilkyardim);
            this.groupBox8.Controls.Add(this.not_dateTimePicker2);
            this.groupBox8.Controls.Add(this.label93);
            this.groupBox8.Controls.Add(this.label92);
            this.groupBox8.Controls.Add(this.not_motor);
            this.groupBox8.Controls.Add(this.not_trafik);
            this.groupBox8.Controls.Add(this.not_tc);
            this.groupBox8.Controls.Add(this.label90);
            this.groupBox8.Controls.Add(this.label89);
            this.groupBox8.Controls.Add(this.label88);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox8.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(985, 362);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            // 
            // buttonGüncelle
            // 
            this.buttonGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonGüncelle.ForeColor = System.Drawing.Color.Black;
            this.buttonGüncelle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonGüncelle.ImageKey = "yenile.png";
            this.buttonGüncelle.ImageList = this.ımageList1;
            this.buttonGüncelle.Location = new System.Drawing.Point(740, 38);
            this.buttonGüncelle.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGüncelle.Name = "buttonGüncelle";
            this.buttonGüncelle.Size = new System.Drawing.Size(164, 67);
            this.buttonGüncelle.TabIndex = 5;
            this.buttonGüncelle.Text = "GÜNCELLE";
            this.buttonGüncelle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonGüncelle.UseVisualStyleBackColor = true;
            this.buttonGüncelle.Click += new System.EventHandler(this.buttonGüncelle_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "yenile.png");
            // 
            // buttonCikis
            // 
            this.buttonCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonCikis.ForeColor = System.Drawing.Color.Black;
            this.buttonCikis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCikis.ImageKey = "cikis.png";
            this.buttonCikis.ImageList = this.ımageList3;
            this.buttonCikis.Location = new System.Drawing.Point(779, 226);
            this.buttonCikis.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCikis.Name = "buttonCikis";
            this.buttonCikis.Size = new System.Drawing.Size(125, 69);
            this.buttonCikis.TabIndex = 7;
            this.buttonCikis.Text = "ÇIKIŞ";
            this.buttonCikis.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonCikis.UseVisualStyleBackColor = true;
            this.buttonCikis.Click += new System.EventHandler(this.buttonCikis_Click);
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "cikis.png");
            // 
            // buttonSil
            // 
            this.buttonSil.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonSil.ForeColor = System.Drawing.Color.Black;
            this.buttonSil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSil.ImageKey = "cop.png";
            this.buttonSil.ImageList = this.ımageList2;
            this.buttonSil.Location = new System.Drawing.Point(792, 131);
            this.buttonSil.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSil.Name = "buttonSil";
            this.buttonSil.Size = new System.Drawing.Size(112, 60);
            this.buttonSil.TabIndex = 6;
            this.buttonSil.Text = "SİL";
            this.buttonSil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSil.UseVisualStyleBackColor = false;
            this.buttonSil.Click += new System.EventHandler(this.buttonSil_Click);
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "cop.png");
            // 
            // not_ilkyardim
            // 
            this.not_ilkyardim.Location = new System.Drawing.Point(353, 283);
            this.not_ilkyardim.Margin = new System.Windows.Forms.Padding(4);
            this.not_ilkyardim.MaxLength = 3;
            this.not_ilkyardim.Name = "not_ilkyardim";
            this.not_ilkyardim.Size = new System.Drawing.Size(230, 23);
            this.not_ilkyardim.TabIndex = 4;
            // 
            // not_dateTimePicker2
            // 
            this.not_dateTimePicker2.Location = new System.Drawing.Point(353, 109);
            this.not_dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.not_dateTimePicker2.Name = "not_dateTimePicker2";
            this.not_dateTimePicker2.Size = new System.Drawing.Size(230, 23);
            this.not_dateTimePicker2.TabIndex = 14;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.ForeColor = System.Drawing.Color.Black;
            this.label93.Location = new System.Drawing.Point(350, 88);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(95, 17);
            this.label93.TabIndex = 9;
            this.label93.Text = "Sınav Tarihi";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.ForeColor = System.Drawing.Color.Black;
            this.label92.Location = new System.Drawing.Point(350, 30);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(153, 17);
            this.label92.TabIndex = 8;
            this.label92.Text = "T.C Kimlik Numarası";
            // 
            // not_motor
            // 
            this.not_motor.Location = new System.Drawing.Point(353, 226);
            this.not_motor.Margin = new System.Windows.Forms.Padding(4);
            this.not_motor.MaxLength = 3;
            this.not_motor.Name = "not_motor";
            this.not_motor.Size = new System.Drawing.Size(230, 23);
            this.not_motor.TabIndex = 3;
            // 
            // not_trafik
            // 
            this.not_trafik.Location = new System.Drawing.Point(353, 168);
            this.not_trafik.Margin = new System.Windows.Forms.Padding(4);
            this.not_trafik.MaxLength = 3;
            this.not_trafik.Name = "not_trafik";
            this.not_trafik.Size = new System.Drawing.Size(230, 23);
            this.not_trafik.TabIndex = 2;
            // 
            // not_tc
            // 
            this.not_tc.Enabled = false;
            this.not_tc.Location = new System.Drawing.Point(353, 51);
            this.not_tc.Margin = new System.Windows.Forms.Padding(4);
            this.not_tc.Name = "not_tc";
            this.not_tc.Size = new System.Drawing.Size(230, 23);
            this.not_tc.TabIndex = 1;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.ForeColor = System.Drawing.Color.Black;
            this.label90.Location = new System.Drawing.Point(350, 262);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(163, 17);
            this.label90.TabIndex = 3;
            this.label90.Text = "İlk Yardım Sınav Notu";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.ForeColor = System.Drawing.Color.Black;
            this.label89.Location = new System.Drawing.Point(350, 205);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(133, 17);
            this.label89.TabIndex = 2;
            this.label89.Text = "Motor Sınav Notu";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.ForeColor = System.Drawing.Color.Black;
            this.label88.Location = new System.Drawing.Point(350, 147);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(134, 17);
            this.label88.TabIndex = 1;
            this.label88.Text = "Trafik Sınav Notu";
            // 
            // hata
            // 
            this.hata.ContainerControl = this;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox1.Location = new System.Drawing.Point(4, 158);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(985, 362);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // notlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(995, 522);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "notlar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Not Bilgileri";
            this.Load += new System.EventHandler(this.notlar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox not_ilkyardim;
        private System.Windows.Forms.DateTimePicker not_dateTimePicker2;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox not_motor;
        private System.Windows.Forms.TextBox not_trafik;
        private System.Windows.Forms.TextBox not_tc;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Button buttonGüncelle;
        private System.Windows.Forms.Button buttonCikis;
        private System.Windows.Forms.Button buttonSil;
        private System.Windows.Forms.ErrorProvider hata;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.ImageList ımageList2;
    }
}