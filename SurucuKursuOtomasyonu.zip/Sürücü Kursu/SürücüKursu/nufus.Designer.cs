﻿namespace SürücüKursu
{
    partial class nufus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(nufus));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dogum_tarih = new System.Windows.Forms.DateTimePicker();
            this.kan_grup = new System.Windows.Forms.TextBox();
            this.dogum_yeri = new System.Windows.Forms.TextBox();
            this.ana = new System.Windows.Forms.TextBox();
            this.baba = new System.Windows.Forms.TextBox();
            this.soyad = new System.Windows.Forms.TextBox();
            this.ad = new System.Windows.Forms.TextBox();
            this.ilçe = new System.Windows.Forms.TextBox();
            this.tc_kimlik = new System.Windows.Forms.TextBox();
            this.il = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.buttonGüncelle = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.buttonCikis = new System.Windows.Forms.Button();
            this.ımageList3 = new System.Windows.Forms.ImageList(this.components);
            this.buttonSil = new System.Windows.Forms.Button();
            this.ımageList2 = new System.Windows.Forms.ImageList(this.components);
            this.hata = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(684, 135);
            this.dataGridView1.TabIndex = 23;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dogum_tarih);
            this.groupBox5.Controls.Add(this.kan_grup);
            this.groupBox5.Controls.Add(this.dogum_yeri);
            this.groupBox5.Controls.Add(this.ana);
            this.groupBox5.Controls.Add(this.baba);
            this.groupBox5.Controls.Add(this.soyad);
            this.groupBox5.Controls.Add(this.ad);
            this.groupBox5.Controls.Add(this.ilçe);
            this.groupBox5.Controls.Add(this.tc_kimlik);
            this.groupBox5.Controls.Add(this.il);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.label53);
            this.groupBox5.Controls.Add(this.label54);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox5.Location = new System.Drawing.Point(3, 158);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(685, 370);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            // 
            // dogum_tarih
            // 
            this.dogum_tarih.Location = new System.Drawing.Point(339, 113);
            this.dogum_tarih.Margin = new System.Windows.Forms.Padding(4);
            this.dogum_tarih.Name = "dogum_tarih";
            this.dogum_tarih.Size = new System.Drawing.Size(199, 23);
            this.dogum_tarih.TabIndex = 40;
            // 
            // kan_grup
            // 
            this.kan_grup.Location = new System.Drawing.Point(339, 179);
            this.kan_grup.Margin = new System.Windows.Forms.Padding(4);
            this.kan_grup.Name = "kan_grup";
            this.kan_grup.Size = new System.Drawing.Size(199, 23);
            this.kan_grup.TabIndex = 32;
            // 
            // dogum_yeri
            // 
            this.dogum_yeri.Location = new System.Drawing.Point(339, 55);
            this.dogum_yeri.Margin = new System.Windows.Forms.Padding(4);
            this.dogum_yeri.MaxLength = 25;
            this.dogum_yeri.Name = "dogum_yeri";
            this.dogum_yeri.Size = new System.Drawing.Size(199, 23);
            this.dogum_yeri.TabIndex = 28;
            // 
            // ana
            // 
            this.ana.Location = new System.Drawing.Point(25, 292);
            this.ana.Margin = new System.Windows.Forms.Padding(4);
            this.ana.MaxLength = 25;
            this.ana.Name = "ana";
            this.ana.Size = new System.Drawing.Size(199, 23);
            this.ana.TabIndex = 27;
            // 
            // baba
            // 
            this.baba.Location = new System.Drawing.Point(25, 232);
            this.baba.Margin = new System.Windows.Forms.Padding(4);
            this.baba.MaxLength = 25;
            this.baba.Name = "baba";
            this.baba.Size = new System.Drawing.Size(199, 23);
            this.baba.TabIndex = 26;
            // 
            // soyad
            // 
            this.soyad.Location = new System.Drawing.Point(25, 178);
            this.soyad.Margin = new System.Windows.Forms.Padding(4);
            this.soyad.MaxLength = 25;
            this.soyad.Name = "soyad";
            this.soyad.Size = new System.Drawing.Size(199, 23);
            this.soyad.TabIndex = 25;
            // 
            // ad
            // 
            this.ad.Location = new System.Drawing.Point(25, 121);
            this.ad.Margin = new System.Windows.Forms.Padding(4);
            this.ad.MaxLength = 25;
            this.ad.Name = "ad";
            this.ad.Size = new System.Drawing.Size(199, 23);
            this.ad.TabIndex = 24;
            // 
            // ilçe
            // 
            this.ilçe.Location = new System.Drawing.Point(339, 288);
            this.ilçe.Margin = new System.Windows.Forms.Padding(4);
            this.ilçe.MaxLength = 25;
            this.ilçe.Name = "ilçe";
            this.ilçe.Size = new System.Drawing.Size(199, 23);
            this.ilçe.TabIndex = 28;
            // 
            // tc_kimlik
            // 
            this.tc_kimlik.Location = new System.Drawing.Point(25, 55);
            this.tc_kimlik.Margin = new System.Windows.Forms.Padding(4);
            this.tc_kimlik.MaxLength = 11;
            this.tc_kimlik.Name = "tc_kimlik";
            this.tc_kimlik.Size = new System.Drawing.Size(199, 23);
            this.tc_kimlik.TabIndex = 23;
            // 
            // il
            // 
            this.il.Location = new System.Drawing.Point(339, 232);
            this.il.Margin = new System.Windows.Forms.Padding(4);
            this.il.MaxLength = 25;
            this.il.Name = "il";
            this.il.Size = new System.Drawing.Size(199, 23);
            this.il.TabIndex = 27;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label41.Location = new System.Drawing.Point(336, 158);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 17);
            this.label41.TabIndex = 11;
            this.label41.Text = "Kan Grubu";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(336, 94);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(105, 17);
            this.label39.TabIndex = 9;
            this.label39.Text = "Doğum Tarihi";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label36.Location = new System.Drawing.Point(336, 34);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(92, 17);
            this.label36.TabIndex = 6;
            this.label36.Text = "Doğum Yeri";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label35.Location = new System.Drawing.Point(22, 271);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 17);
            this.label35.TabIndex = 5;
            this.label35.Text = "Ana Adı";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label34.Location = new System.Drawing.Point(22, 211);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(73, 17);
            this.label34.TabIndex = 4;
            this.label34.Text = "Baba Adı";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label33.Location = new System.Drawing.Point(22, 158);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(57, 17);
            this.label33.TabIndex = 3;
            this.label33.Text = "Soyadı";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label32.Location = new System.Drawing.Point(22, 100);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(31, 17);
            this.label32.TabIndex = 2;
            this.label32.Text = "Adı";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(22, 34);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(153, 17);
            this.label31.TabIndex = 1;
            this.label31.Text = "T.C Kimlik Numarası";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label53.Location = new System.Drawing.Point(336, 211);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(16, 17);
            this.label53.TabIndex = 8;
            this.label53.Text = "İl";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label54.Location = new System.Drawing.Point(336, 267);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(33, 17);
            this.label54.TabIndex = 9;
            this.label54.Text = "İlçe";
            // 
            // buttonGüncelle
            // 
            this.buttonGüncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonGüncelle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonGüncelle.ImageKey = "yenile.png";
            this.buttonGüncelle.ImageList = this.ımageList1;
            this.buttonGüncelle.Location = new System.Drawing.Point(4, 535);
            this.buttonGüncelle.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGüncelle.Name = "buttonGüncelle";
            this.buttonGüncelle.Size = new System.Drawing.Size(149, 49);
            this.buttonGüncelle.TabIndex = 27;
            this.buttonGüncelle.Text = "GÜNCELLE";
            this.buttonGüncelle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonGüncelle.UseVisualStyleBackColor = true;
            this.buttonGüncelle.Click += new System.EventHandler(this.buttonGüncelle_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "yenile.png");
            // 
            // buttonCikis
            // 
            this.buttonCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonCikis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCikis.ImageKey = "cikis.png";
            this.buttonCikis.ImageList = this.ımageList3;
            this.buttonCikis.Location = new System.Drawing.Point(579, 535);
            this.buttonCikis.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCikis.Name = "buttonCikis";
            this.buttonCikis.Size = new System.Drawing.Size(109, 50);
            this.buttonCikis.TabIndex = 26;
            this.buttonCikis.Text = "ÇIKIŞ";
            this.buttonCikis.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonCikis.UseVisualStyleBackColor = true;
            this.buttonCikis.Click += new System.EventHandler(this.buttonCikis_Click);
            // 
            // ımageList3
            // 
            this.ımageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList3.ImageStream")));
            this.ımageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList3.Images.SetKeyName(0, "cikis.png");
            // 
            // buttonSil
            // 
            this.buttonSil.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonSil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSil.ImageKey = "cop.png";
            this.buttonSil.ImageList = this.ımageList2;
            this.buttonSil.Location = new System.Drawing.Point(159, 535);
            this.buttonSil.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSil.Name = "buttonSil";
            this.buttonSil.Size = new System.Drawing.Size(93, 49);
            this.buttonSil.TabIndex = 25;
            this.buttonSil.Text = "SİL";
            this.buttonSil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSil.UseVisualStyleBackColor = false;
            this.buttonSil.Click += new System.EventHandler(this.buttonSil_Click_1);
            // 
            // ımageList2
            // 
            this.ımageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList2.ImageStream")));
            this.ımageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList2.Images.SetKeyName(0, "cop.png");
            // 
            // hata
            // 
            this.hata.ContainerControl = this;
            // 
            // nufus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(701, 585);
            this.Controls.Add(this.buttonGüncelle);
            this.Controls.Add(this.buttonCikis);
            this.Controls.Add(this.buttonSil);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "nufus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nüfus Bilgileri";
            this.Load += new System.EventHandler(this.NufusBilgileri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hata)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DateTimePicker dogum_tarih;
        private System.Windows.Forms.TextBox ilçe;
        private System.Windows.Forms.TextBox il;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox kan_grup;
        private System.Windows.Forms.TextBox dogum_yeri;
        private System.Windows.Forms.TextBox ana;
        private System.Windows.Forms.TextBox baba;
        private System.Windows.Forms.TextBox soyad;
        private System.Windows.Forms.TextBox ad;
        private System.Windows.Forms.TextBox tc_kimlik;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button buttonGüncelle;
        private System.Windows.Forms.Button buttonCikis;
        private System.Windows.Forms.Button buttonSil;
        private System.Windows.Forms.ErrorProvider hata;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.ImageList ımageList3;
        private System.Windows.Forms.ImageList ımageList2;
    }
}